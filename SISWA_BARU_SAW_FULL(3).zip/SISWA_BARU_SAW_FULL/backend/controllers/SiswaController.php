<?php

namespace backend\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use backend\models\Siswa;
use backend\models\SiswaUpload;
use backend\models\Nilaiuan;
use backend\models\NilaiUanDetail;
use backend\models\Pengaturan;
use backend\models\Jurusan;
use backend\models\Kriteria;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class SiswaController extends Controller
{
	/**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function beforeAction($action) {
        $this->enableCsrfValidation = false;
        return parent::beforeAction($action);
    }

    public function actionAjax()
    {
        $saat_ini = date("Y-m-d");
        $modelPengaturan = Pengaturan::find()
            ->where(':tgl_mulai >= tgl_mulai', [':tgl_mulai' => $saat_ini])
            ->andWhere(':tgl_selesai <= tgl_selesai', [':tgl_selesai' => $saat_ini])
            ->one();

        if(!empty($modelPengaturan)){
            $id_pengaturan = $modelPengaturan->id_pengaturan;
        }else{
            $id_pengaturan = "";
        }

        $requestData = Yii::$app->request->get();
        $id_pengaturan = Yii::$app->request->get('ta')=="" ? $id_pengaturan : Yii::$app->request->get('ta');
        $id_jurusan = Yii::$app->request->get('jur')=="" ? "" : Yii::$app->request->get('jur');
        $start = Yii::$app->request->get('start')==null ? 1 : Yii::$app->request->get('start');
        $length = Yii::$app->request->get('length')==null ? 10 : Yii::$app->request->get('length');
        $draw = Yii::$app->request->get('draw');//==null ? 10 : Yii::$app->request->get('length');
        $columns = array(
            0=> 'id_siswa',
            1=> 'nama_jurusan',
            2=> 'nisn',
            3=> 'nama_siswa',
            4=> 'tempat_lahir',
            5=> 'jenis_kelamin',
            6=> 'agama',
            7=> 'alamat',
            8=> 'status_verifikasi',
            9=> '',
        );

        $sql = "SELECT  s.*,j.nama_jurusan FROM siswa s"
           . " INNER JOIN jurusan j ON s.id_jurusan=j.id_jurusan"
           . " WHERE s.id_pengaturan = '".$id_pengaturan."' ";
           //. " WHERE nisn IS NULL";
        if($id_jurusan!=""){
            $sql .= " AND s.id_jurusan = '".$id_jurusan."' ";
        }
   
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        $totalData = count($data);
        $totalFiltered = $totalData;
             
        if (!empty($requestData['search']['value']))
        {
            $sql.=" AND ( j.nama_jurusan LIKE '%" . $requestData['search']['value'] . "%' ";
            $sql.=" OR s.nama_siswa LIKE '%" . $requestData['search']['value'] . "%'";
            $sql.=" OR s.agama LIKE '%" . $requestData['search']['value'] . "%')";
        }
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        $totalFiltered = count($data);
        if (!empty($requestData['order']['0']))
        {
            $sql.=" ORDER BY ".$columns[$requestData['order']['0']['column']]." ".$requestData['order']['0']['dir']." "; 
        }else{
            $sql.=" ORDER BY nama_jurusan ASC, nisn ASC ";
        }
        $sql.=" LIMIT " . $start . " ," . 
        $length. " ";
        $result = Yii::$app->db->createCommand($sql)->queryAll();
       
        $data = array();
        $i=1;
        foreach ($result as $key => $row)
        {
            $nestedData = array();
            $urlUpdate = Yii::$app->request->baseUrl.'/siswa/update/'.$row["id_siswa"];
            $posisi = $start+$i;
            $nestedData[] = '<div class="custom-control custom-checkbox mb-1">'
                    . '<input type="checkbox" class="custom-control-input" id="formsCheckboxDefault'.$i.'" name="pilih['.$row['id_siswa'].']" value="'.$row['id_siswa'].'">'
                    . '<label class="custom-control-label" for="formsCheckboxDefault'.$i.'">'.$posisi.'</label>'
                    . '</div>';
            $nestedData[] = $row["nama_jurusan"];
            $nestedData[] = $row["nisn"];
            $nestedData[] = $row["nama_siswa"];
            $nestedData[] = $row["tempat_lahir"].', '.$row["tgl_lahir"];
            $nestedData[] = $row["jenis_kelamin"];
            $nestedData[] = $row["agama"];
            $nestedData[] = $row["alamat"];
            $nestedData[] = $row["status_verifikasi"];
            $nestedData[] = "<a href='$urlUpdate' title='Update' aria-label='View' data-pjax='0'>"
                    . "<button type='button' class='mb-2 btn btn-sm btn-primary mr-1'><i class='material-icons'>edit</i></button></a>";
             $data[] = $nestedData;
             $i++;
        }

        $json_data = array(
            "draw" => $draw, 
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data   // total data array
        );

        return \yii\helpers\Json::encode($json_data);
    }

    /**
     * Lists all Siswa models.
     * @return mixed
     */
    public function actionIndex()
    {
        //$siswaQuery = Siswa::find()->where(['is', 'nisn' , new \yii\db\Expression('null')])->indexBy('id_siswa')->orderBy('nisn')->all();
        $pengaturanQuery = Pengaturan::find()->indexBy('id_pengaturan')->orderBy('tahun_ajaran')->all();
        $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();

        $model = new \yii\base\DynamicModel([
        'id_pengaturan', 'id_jurusan'
        ]);
        $model->addRule(['id_pengaturan', 'id_jurusan'], 'required');

        $saat_ini = date("Y-m-d");
        $modelPengaturan = Pengaturan::find()
        	->where(':tgl_mulai >= tgl_mulai', [':tgl_mulai' => $saat_ini])
        	->andWhere(':tgl_selesai <= tgl_selesai', [':tgl_selesai' => $saat_ini])
        	->one();

        $siswaQuery = array();

        if(!empty($modelPengaturan)){
            if ($model->load(Yii::$app->request->post())){
                $siswaQuery = Siswa::find()
                ->where(':id_pengaturan = id_pengaturan', [':id_pengaturan' => $model->id_pengaturan])
                ->andWhere(':id_jurusan = id_jurusan', [':id_jurusan' => $model->id_jurusan])
                ->indexBy('id_siswa')->orderBy('nisn')->all();
            }else{
                $model->id_pengaturan = $modelPengaturan->id_pengaturan;
            }
        }

        return $this->render('index', [
            'model' => $model,
            'dataProvider' => $siswaQuery,
            'modelPengaturan' => $pengaturanQuery,
            'modelJurusan' => $jurusanQuery,
            'modelSaatini' => $modelPengaturan,
        ]);
    }

    /**
     * Displays a single Siswa model.
     * @param string $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    //IMPORT DATA CALON SISWA
    public function actionImport(){
        $model = new SiswaUpload();

        $pengaturanQuery = Pengaturan::find()->indexBy('id_pengaturan')->orderBy('tahun_ajaran')->all();
        $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();

        if (Yii::$app->request->post()){
            $uploadedFile = \yii\web\UploadedFile::getInstanceByName('file');
            $extension =$uploadedFile->extension;
            if($extension=='xlsx'){
                $inputFileType = 'Xlsx';
            }else{
                $inputFileType = 'Xls';
            }
            
            $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($inputFileType);
             

            $spreadsheet = $reader->load($uploadedFile->tempName);
            $worksheet = $spreadsheet->getActiveSheet();
            $highestRow = $worksheet->getHighestRow();
            $highestColumn = $worksheet->getHighestColumn();
            $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);

            /*
            Nilai Matematika = Row 5    C1
            Nilai IPA = Row 6           C2
            Nilai BHS INDONESIA = Row 7 C3
            Nilai BHS INGGRIS = Row 8   C4
            Nilai PRESTASI = Row 9      C5
            */
            $kriteriaQuery = Kriteria::find()->indexBy('id_kriteria')->orderBy('kode_kriteria')->all();
            $kriteria = array();
            foreach ($kriteriaQuery as $key => $dtKriteria) {
                $kriteria[$dtKriteria->kode_kriteria] = $dtKriteria->id_kriteria;
            }

             
            //inilah looping untuk membaca cell dalam file excel,perkolom
            $data_siswa = array();
            $idx = 0;
            for ($row = 30; $row <= $highestRow; ++$row) { //$row = 30 artinya baris kedua yang dibaca dulu(header kolom diskip disesuaikan saja)
                //for ($col = 1; $col <= $highestColumnIndex; ++$col) {
                $data_siswa[$idx]['nama'] = $worksheet->getCellByColumnAndRow(2, $row)->getValue(); //2 artinya kolom ke2
                $data_siswa[$idx]['jk'] = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
                $data_siswa[$idx]['agama'] = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
                $data_siswa[$idx]['C1'] = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
                $data_siswa[$idx]['C2'] = $worksheet->getCellByColumnAndRow(6, $row)->getValue();
                $data_siswa[$idx]['C3'] = $worksheet->getCellByColumnAndRow(7, $row)->getValue();
                $data_siswa[$idx]['C4'] = $worksheet->getCellByColumnAndRow(8, $row)->getValue();
                $data_siswa[$idx]['C5'] = $worksheet->getCellByColumnAndRow(9, $row)->getValue();
                
                $idx++;
            }
            
            //DEKLARASI VARIABEL POST
            $request = Yii::$app->request;
            $id_jurusan = $request->post('SiswaUpload')['id_jurusan'];
            $id_pengaturan = $request->post('SiswaUpload')['id_pengaturan'];
            
            //INSERT TABEL SISWA
            foreach ($data_siswa as $key => $arrRows) {
                $modelSiswa = new SiswaUpload();
                $modelUn = new Nilaiuan();

                $modelSiswa->id_jurusan = $id_jurusan;
                $modelSiswa->id_pengaturan = $id_pengaturan;
                $modelSiswa->nama_siswa = $arrRows['nama'];
                $modelSiswa->jenis_kelamin = $arrRows['jk'];
                $modelSiswa->agama = $arrRows['agama'];
                $modelSiswa->status_verifikasi = 'Sudah';

                if($modelSiswa->save()){
                    $modelUn->id_siswa = $modelSiswa->id_siswa;
                    if($modelUn->save()){
                        foreach ($kriteria as $kode_kriteria => $id_kriteria) {
                            if(!empty($arrRows[$kode_kriteria])){
                                $modelNilaiSimpan = new NilaiUanDetail();
                                $modelNilaiSimpan->id_un = $modelUn->id_un;
                                $modelNilaiSimpan->id_kriteria = $id_kriteria;
                                $modelNilaiSimpan->nilai = $arrRows[$kode_kriteria];
                                $modelNilaiSimpan->save();
                            }
                        }
                    }
                }
            }
            Yii::$app->session->setFlash('success', 'Data calon siswa berhasil diimport');
            //return $this->redirect(['index']);
            return Yii::$app->getResponse()->redirect(['siswa/index']);
            
        }else{
            return $this->render('import', [
                'model' => $model,
                'modelJurusan' => $jurusanQuery,
                'modelPengaturan' => $pengaturanQuery,
            ]);
        }
    }

    /**
     * Creates a new Siswa model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $kriteriaQuery = Kriteria::find()->indexBy('id_kriteria')->orderBy('kode_kriteria')->all();
        $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();
        $model = new Siswa();
        $modelUn = new Nilaiuan();
        $modelNilai = new NilaiUanDetail();
        $saat_ini = date("Y-m-d");
        $modelPengaturan = Pengaturan::find()
        	->where(':tgl_mulai >= tgl_mulai', [':tgl_mulai' => $saat_ini])
        	->andWhere(':tgl_selesai <= tgl_selesai', [':tgl_selesai' => $saat_ini])
        	->one();

        $tgl_lahir = date("Y-m-d", strtotime($model->tgl_lahir));
        $model->tgl_lahir = $tgl_lahir;
        $model->id_pengaturan	= $modelPengaturan->id_pengaturan;
        $model->status_verifikasi = 'Sudah';

        //Simpan Siswa
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            //Simpan Nilai UN
            $modelUn->id_siswa = $model->id_siswa;
            if($modelUn->save()){
                if ($modelNilai->load(Yii::$app->request->post())){
                    if(!empty($modelNilai['id_kriteria'])){
                        foreach ($modelNilai['id_kriteria'] as $id_kriteria => $nilai) {
                            $modelNilaiSimpan = new NilaiUanDetail();
                            $modelNilaiSimpan->id_un = $modelUn->id_un;
                            $modelNilaiSimpan->id_kriteria = $id_kriteria;
                            $modelNilaiSimpan->nilai = $nilai;
                            $modelNilaiSimpan->save();
                        }
                    }
                }
            }
            //return $this->redirect(['index']);
            Yii::$app->session->setFlash('success', 'Data siswa berhasil disimpan');
            return Yii::$app->getResponse()->redirect(['siswa/index']);
        } else {
            return $this->render('create', [
                'model' => $model,
                'modelUn' => $modelUn,
                'modelPengaturan' => $modelPengaturan,
                'modelJurusan' => $jurusanQuery,
                'modelKriteria' => $kriteriaQuery,
                'modelNilai' => $modelNilai,
            ]);
        }
    }

    /**
     * Updates an existing Siswa model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $kriteriaQuery = Kriteria::find()->indexBy('id_kriteria')->orderBy('kode_kriteria')->all();
        $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();
        $model = $this->findModel($id);
        $modelUn = Nilaiuan::find()->where(['id_siswa' => $id])->one();
        $modelNilai = new NilaiUanDetail();

        $tgl_lahir = date("Y-m-d", strtotime($model->tgl_lahir));
        
        $model->tgl_lahir = $tgl_lahir;

        $nilai_id = array();
        if(!empty($modelUn)){
            $dataNilai = NilaiUanDetail::find()
                    ->select(['id_kriteria', 'nilai'])
                    ->where(['id_un' => $modelUn->id_un])
                    ->asArray()
                    ->all();
            foreach($dataNilai as $row) {
                $nilai_id[$row['id_kriteria']] = $row['nilai'];
            }
        }


        if ($model->load(Yii::$app->request->post())) {
            
            $model->status_verifikasi = ($_POST['Siswa']['status_verifikasi']);
            if($model->save()){
                if ($modelNilai->load(Yii::$app->request->post())){
                    if(!empty($modelNilai['id_kriteria'])){
                        //HAPUS DATA SEBELUMNYA
                        NilaiUanDetail::deleteAll(['id_un' => $modelUn->id_un]);
                        foreach ($modelNilai['id_kriteria'] as $id_kriteria => $nilai) {
                            $modelNilaiSimpan = new NilaiUanDetail();
                            $modelNilaiSimpan->id_un = $modelUn->id_un;
                            $modelNilaiSimpan->id_kriteria = $id_kriteria;
                            $modelNilaiSimpan->nilai = $nilai;
                            $modelNilaiSimpan->save();
                        }
                    }
                }

                Yii::$app->session->setFlash('success', 'Data calon siswa berhasil diubah');
                //return $this->redirect(['index']);
                return Yii::$app->getResponse()->redirect(['siswa/index']);
            }else{
                Yii::$app->session->setFlash('error', 'Data calon siswa gagal diubah');
                return $this->render('update', [
                    'model' => $model,
                    'modelUn' => $modelUn,
                    'modelJurusan' => $jurusanQuery,
                    'modelKriteria' => $kriteriaQuery,
                    'modelNilai' => $modelNilai,
                    'dataNilai' => $nilai_id,
                ]);
            }
        } else {
            return $this->render('update', [
                'model' => $model,
                'modelUn' => $modelUn,
                'modelJurusan' => $jurusanQuery,
                'modelKriteria' => $kriteriaQuery,
                'modelNilai' => $modelNilai,
                'dataNilai' => $nilai_id,
            ]);
        }
    }

     /**
     * Deletes an existing Siswa model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
    public function actionDelete()
    {

        if(!empty($_POST['pilih'])){
			$pilih = $_POST['pilih'];
			foreach ($pilih as $id_siswa => $value) {
				$this->findModel($id_siswa)->delete();
			}
		}

        Yii::$app->session->setFlash('success', 'Data calon siswa berhasil dihapus');

        //return $this->redirect(['index']);
        return Yii::$app->getResponse()->redirect(['siswa/index']);
    }


    /**
     * Finds the Siswa model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Siswa the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Siswa::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
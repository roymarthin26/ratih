<?php

namespace backend\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use backend\models\LoginForm;
use backend\models\Pengaturan;
use backend\models\Siswa;

class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['get'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        if (!Yii::$app->user->isGuest) {
            //return $this->goHome();
            return $this->redirect(['/beranda']);
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        } else {
            $model->password = '';
            // views/layouts/main_login.php
            $this->layout = 'main_login';

            return $this->render('login', [
                'model' => $model,
            ]);
        }
    }

    public function actionBeranda()
    {
        if (Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $saat_ini = date("Y-m-d");
        $modelPengaturan = Pengaturan::find()
            ->where(':tgl_mulai >= tgl_mulai', [':tgl_mulai' => $saat_ini])
            ->andWhere(':tgl_selesai <= tgl_selesai', [':tgl_selesai' => $saat_ini])
            ->one();

        if(!empty($modelPengaturan->tahun_ajaran)){

            //Total Pendaftar
            $modelTotalPendaftar = Siswa::find()
                ->where('id_pengaturan = :id_pengaturan', [':id_pengaturan' => $modelPengaturan->id_pengaturan])
                ->count();
            //Total Diterima
            $modelTotalDiterima = (new yii\db\Query())
                ->from('ranking')
                ->join( 'JOIN', 
                    'detail_ranking',
                    'ranking.id_ranking =detail_ranking.id_ranking'
                )
                ->join( 'JOIN', 
                    'siswa',
                    'siswa.id_siswa =detail_ranking.id_siswa'
                )
                ->where('siswa.id_pengaturan = :id_pengaturan', [':id_pengaturan' => $modelPengaturan->id_pengaturan])
                ->count();

            $persen = 0;

            //Hasil Perangkingan
            $modelPerangkingan = new \yii\db\Query();
            $modelPerangkingan  ->select(['*'])  
                    ->from('ranking')
                    ->join( 'JOIN', 
                        'detail_ranking',
                        'ranking.id_ranking =detail_ranking.id_ranking'
                    )
                    ->join( 'JOIN', 
                        'siswa',
                        'siswa.id_siswa =detail_ranking.id_siswa'
                    )
                    ->where('siswa.id_pengaturan = :id_pengaturan', [':id_pengaturan' => $modelPengaturan->id_pengaturan]); 
            $command = $modelPerangkingan->createCommand();
            $data = $command->queryAll();
        }else{
            $modelTotalPendaftar = array();
            $modelTotalDiterima = array();
            $persen = 0;
            $data = array();
        }

        return $this->render('beranda', [
            'modelTotalPendaftar' => $modelTotalPendaftar,
            'modelTotalDiterima' => $modelTotalDiterima,
            'persen' => $persen,
            'modelPengaturan' => $modelPengaturan,
            'modelPerangkingan' => $data,
        ]);
    }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->redirect(['/beranda']);
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            //return $this->goBack();
            //print_r($_POST);
        }

        $model->password = '';
        $this->layout = 'main_login';

        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }
}

<?php

namespace backend\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use backend\models\Perangkingan;
use backend\models\DetailRanking;
use backend\models\Pengaturan;
use backend\models\PengaturanKriteria;
use backend\models\Siswa;
use backend\models\Jurusan;
use backend\models\Kelas;
use backend\models\NilaiUanDetail;

class HasilController extends Controller
{
	/**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function actionAjax()
    {
        $saat_ini = date("Y-m-d");
        $modelPengaturan = Pengaturan::find()
            ->where(':tgl_mulai >= tgl_mulai', [':tgl_mulai' => $saat_ini])
            ->andWhere(':tgl_selesai <= tgl_selesai', [':tgl_selesai' => $saat_ini])
            ->one();

        if(!empty($modelPengaturan)){
            $id_pengaturan = $modelPengaturan->id_pengaturan;
        }else{
            $id_pengaturan = "";
        }

        $requestData = Yii::$app->request->get();
        $id_pengaturan = Yii::$app->request->get('ta')=="" ? $id_pengaturan : Yii::$app->request->get('ta');
        $id_jurusan = Yii::$app->request->get('jur')=="" ? "" : Yii::$app->request->get('jur');
        $start = Yii::$app->request->get('start')==null ? 1 : Yii::$app->request->get('start');
        $length = Yii::$app->request->get('length')==null ? 10 : Yii::$app->request->get('length');
        $draw = Yii::$app->request->get('draw');//==null ? 10 : Yii::$app->request->get('length');
        $columns = array(
            0=> 'nisn',
            1=> 'nama_siswa',
            2=> 'nama_jurusan',
            3=> 'nama_kelas',
            4=> 'nilai',
            5=> 'urutan',
        );

        $sql = "SELECT  s.*,j.nama_jurusan, nama_kelas, dr.urutan, dr.nilai FROM ranking r"
           . " INNER JOIN detail_ranking dr ON r.id_ranking=dr.id_ranking"
           . " INNER JOIN siswa s ON dr.id_siswa=s.id_siswa"
           . " INNER JOIN kelas k ON dr.id_kelas=k.id_kelas"
           . " INNER JOIN jurusan j ON k.id_jurusan=j.id_jurusan"
           . " WHERE s.id_pengaturan = '".$id_pengaturan."' "
           . " AND s.id_jurusan = '".$id_jurusan."' ";
           //. " WHERE nisn IS NULL";

        //$data = Yii::$app->db->createCommand($sql)->queryAll();
        //$totalData = count($data);
        //$totalFiltered = $totalData;
             
        if (!empty($requestData['search']['value']))
        {
            $sql.=" AND ( j.nama_jurusan LIKE '%" . $requestData['search']['value'] . "%' ";
            $sql.=" OR s.nama_siswa LIKE '%" . $requestData['search']['value'] . "%'";
            $sql.=" OR k.nama_kelas LIKE '%" . $requestData['search']['value'] . "%')";
        }
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        $totalData = count($data);
        $totalFiltered = count($data);
        if (!empty($requestData['order']['0']))
        {
            $sql.=" ORDER BY ".$columns[$requestData['order']['0']['column']]." ".$requestData['order']['0']['dir']." "; 
        }else{
            $sql.=" ORDER BY dr.urutan ASC";
        }
        $sql.=" LIMIT " . $start . " ," . 
        $length. " ";
        $result = Yii::$app->db->createCommand($sql)->queryAll();
       
        $data = array();
        $i=1;
        foreach ($result as $key => $row)
        {
            $nestedData = array();
            
            $nestedData[] = $row["nisn"];
            $nestedData[] = $row["nama_siswa"];
            $nestedData[] = $row["nama_jurusan"];
            $nestedData[] = $row["nama_kelas"];
            $nestedData[] = round($row["nilai"],3);
            $nestedData[] = $row["urutan"];
             $data[] = $nestedData;
             $i++;
        }

        $json_data = array(
            "draw" => $draw, 
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data   // total data array
        );

        return \yii\helpers\Json::encode($json_data);
    }

    /**
     * Lists all Perangkingan models.
     * @return mixed
     */
    public function actionIndex()
    {
        $pengaturanQuery = Pengaturan::find()->indexBy('id_pengaturan')->orderBy('tahun_ajaran')->all();
        $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();
        $perangkinganQuery = new Perangkingan();

        $model = new \yii\base\DynamicModel([
        'id_pengaturan', 'id_jurusan'
        ]);
        $model->addRule(['id_pengaturan', 'id_jurusan'], 'required');

        $saat_ini = date("Y-m-d");
        $modelPengaturan = Pengaturan::find()
            ->where(':tgl_mulai >= tgl_mulai', [':tgl_mulai' => $saat_ini])
            ->andWhere(':tgl_selesai <= tgl_selesai', [':tgl_selesai' => $saat_ini])
            ->one();

        if (Yii::$app->request->post()){

            $request = Yii::$app->request;
            $id_pengaturan = $request->post('DynamicModel')['id_pengaturan'];
            $id_jurusan = $request->post('DynamicModel')['id_jurusan'];

            $model->id_pengaturan = $id_pengaturan;
            $model->id_jurusan = $id_jurusan;

            $modelPerangkingan = new \yii\db\Query();
            $modelPerangkingan  ->select(['nisn', 'nama_siswa', 'nama_jurusan', 'nama_kelas', 'nilai', 'detail_ranking.urutan'])  
                    ->from('ranking')
                    ->join( 'JOIN', 
                        'detail_ranking',
                        'ranking.id_ranking = detail_ranking.id_ranking'
                    )
                    ->join( 'JOIN', 
                        'siswa',
                        'siswa.id_siswa = detail_ranking.id_siswa'
                    )
                    ->join( 'JOIN', 
                        'kelas',
                        'detail_ranking.id_kelas = kelas.id_kelas'
                    )
                    ->join( 'JOIN', 
                        'jurusan',
                        'kelas.id_jurusan = jurusan.id_jurusan'
                    )
                    ->where('siswa.id_pengaturan = :id_pengaturan', [':id_pengaturan' => $id_pengaturan]) 
                    ->andWhere('siswa.id_jurusan = :id_jurusan', [':id_jurusan' => $id_jurusan]); 
            $command = $modelPerangkingan->createCommand();
            $data = $command->queryAll();

        }else{
            $data = array();
            $data = array();
        }

        return $this->render('index', [
            'model' => $model,
            'modelPerangkingan' => $data,
            'modelPengaturan' => $pengaturanQuery,
            'modelJurusan' => $jurusanQuery,
            'modelSaatini' => $modelPengaturan,
        ]);
    }

    /**
     * Finds the Perangkingan model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Perangkingan the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Perangkingan::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
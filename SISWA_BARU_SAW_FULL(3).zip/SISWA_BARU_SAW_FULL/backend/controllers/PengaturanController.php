<?php

namespace backend\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use backend\models\Kriteria;
use backend\models\Pengaturan;
use backend\models\PengaturanKriteria;

class PengaturanController extends Controller
{
	/**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function beforeAction($action) {
        $this->enableCsrfValidation = false;
        return parent::beforeAction($action);
    }

    /**
     * Lists all Pengaturan models.
     * @return mixed
     */
    public function actionIndex()
    {
        $kriteriaQuery = Kriteria::find()->indexBy('id_kriteria')->orderBy('kode_kriteria')->all();
        $pengaturanQuery = Pengaturan::find()->indexBy('id_pengaturan')->orderBy('tahun_ajaran')->all();

        //Get Data

        $sql = "SELECT *, (SELECT CONCAT('{', GROUP_CONCAT(CONCAT('";
        $sql .= '"';
        $sql .= "',id_kriteria,'";
        $sql .= '":"';
        $sql .= "',bobot,'";
        $sql .= '"';
        $sql .= "')),'}') as json ";
        $sql .= "FROM pengaturan_kriteria pk
                WHERE pk.id_pengaturan=p.id_pengaturan) as pk 
                FROM pengaturan p";

        $data_pengaturan = Yii::$app->db->createCommand($sql)->queryAll();

        return $this->render('index', [
            'dataProvider' => $pengaturanQuery,
            'dataPengaturan' => $data_pengaturan,
            'dataKriteria' => $kriteriaQuery,
        ]);
    }


    /**
     * Creates a new Pengaturan model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $kriteriaQuery = Kriteria::find()->indexBy('id_kriteria')->orderBy('kode_kriteria')->all();
        $model = new Pengaturan();
        $modelPK = new PengaturanKriteria();
        
        $model->load(Yii::$app->request->post());
        $mulai = date("Y", strtotime($model->tgl_mulai));
        $selesai = date("Y", strtotime($model->tgl_selesai));
        $model->tahun_ajaran = $mulai.'/'.$selesai;

        //CEK TOTAL BOBOT == 100
        $bobotPK = 0;
        if ($modelPK->load(Yii::$app->request->post())){
            if(!empty($modelPK['id_kriteria'])){
                $bobotPK = array_sum($modelPK['id_kriteria']);
            }
        }
        
        if ($model->load(Yii::$app->request->post())) {
            if($bobotPK == 100){
                if($model->save()){
                    //Simpan Pengaturan Kriteria
                    if ($modelPK->load(Yii::$app->request->post())){
                        if(!empty($modelPK['id_kriteria'])){
                            foreach ($modelPK['id_kriteria'] as $id_kriteria => $bobot) {
                                $modelPKSimpan = new PengaturanKriteria();
                                $modelPKSimpan->id_pengaturan = $model->id_pengaturan;
                                $modelPKSimpan->id_kriteria = $id_kriteria;
                                $modelPKSimpan->bobot = $bobot;
                                $modelPKSimpan->save();
                            }
                        }
                    }

                    Yii::$app->session->setFlash('success', 'Data pengaturan berhasil disimpan');
                    return $this->redirect(['index']);
                }
            }else{
                Yii::$app->session->setFlash('error', 'Total Bobot Kriteria Harus 100');
            }

            return $this->render('create', [
                'model' => $model,
                'modelKriteria' => $kriteriaQuery,
                'modelPK' => $modelPK,
            ]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'modelKriteria' => $kriteriaQuery,
                'modelPK' => $modelPK,
            ]);
        }
    }

    /**
     * Updates an existing Pengaturan model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $kriteriaQuery = Kriteria::find()->indexBy('id_kriteria')->orderBy('kode_kriteria')->all();
        $model = $this->findModel($id);
        $modelPK = new PengaturanKriteria();
        $pk_id = array();
        $dataPK = PengaturanKriteria::find()
                ->select(['id_kriteria', 'bobot'])
                ->where(['id_pengaturan' => $id])
                ->asArray()
                ->all();
        foreach($dataPK as $row) {
            $pk_id[$row['id_kriteria']] = $row['bobot'];
        }
        
        $model->load(Yii::$app->request->post());
        $mulai = date("Y", strtotime($model->tgl_mulai));
        $selesai = date("Y", strtotime($model->tgl_selesai));
        $model->tahun_ajaran = $mulai.'/'.$selesai;

        //CEK TOTAL BOBOT == 100
        $bobotPK = 0;
        if ($modelPK->load(Yii::$app->request->post())){
            if(!empty($modelPK['id_kriteria'])){
                $bobotPK = array_sum($modelPK['id_kriteria']);
            }
        }

        if ($model->load(Yii::$app->request->post())) {

            if($bobotPK == 100){
                if($model->save()){
                    //Simpan Pengaturan Kriteria
                    if ($modelPK->load(Yii::$app->request->post())){
                        if(!empty($modelPK['id_kriteria'])){
                            //HAPUS DATA SEBELUMNYA
                            PengaturanKriteria::deleteAll(['id_pengaturan' => $model->id_pengaturan]);
                            foreach ($modelPK['id_kriteria'] as $id_kriteria => $bobot) {
                                $modelPKSimpan = new PengaturanKriteria();
                                $modelPKSimpan->id_pengaturan = $model->id_pengaturan;
                                $modelPKSimpan->id_kriteria = $id_kriteria;
                                $modelPKSimpan->bobot = $bobot;
                                $modelPKSimpan->save();
                            }
                        }
                    }

                    Yii::$app->session->setFlash('success', 'Data pengaturan berhasil diubah');
                    return $this->redirect(['index']);
                }
            }else{
                Yii::$app->session->setFlash('error', 'Total Bobot Kriteria Harus 100');
            }

            return $this->render('update', [
                'model' => $model,
                'modelKriteria' => $kriteriaQuery,
                'modelPK' => $modelPK,
                'dataPK' => $pk_id,
            ]);
        } else {
            return $this->render('update', [
                'model' => $model,
                'modelKriteria' => $kriteriaQuery,
                'modelPK' => $modelPK,
                'dataPK' => $pk_id,
            ]);
        }
    }

     /**
     * Deletes an existing Pengaturan model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
    public function actionDelete()
    {
		if(!empty($_POST['pilih'])){
            $pilih = $_POST['pilih'];
            foreach ($pilih as $id_pengaturan => $value) {
                $this->findModel($id_pengaturan)->delete();
            }
        }
        Yii::$app->session->setFlash('success', 'Data pengaturan berhasil dihapus');
        return $this->redirect(['index']);
    }

    /**
     * Finds the Pengaturan model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Pengaturan the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Pengaturan::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
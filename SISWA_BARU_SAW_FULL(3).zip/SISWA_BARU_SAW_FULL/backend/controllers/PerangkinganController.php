<?php

namespace backend\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use backend\models\Perangkingan;
use backend\models\DetailRanking;
use backend\models\Pengaturan;
use backend\models\PengaturanKriteria;
use backend\models\Siswa;
use backend\models\Jurusan;
use backend\models\Kelas;
use backend\models\NilaiUanDetail;

class PerangkinganController extends Controller
{
	/**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Perangkingan models.
     * @return mixed
     */
    public function actionIndex()
    {
        $pengaturanQuery = Pengaturan::find()->indexBy('id_pengaturan')->orderBy('tahun_ajaran')->all();
        $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();
        $perangkinganQuery = new Perangkingan();

        $model = new \yii\base\DynamicModel([
        'id_pengaturan', 'id_jurusan'
        ]);
        $model->addRule(['id_pengaturan', 'id_jurusan'], 'required');

        $saat_ini = date("Y-m-d");
        $modelPengaturan = Pengaturan::find()
            ->where(':tgl_mulai >= tgl_mulai', [':tgl_mulai' => $saat_ini])
            ->andWhere(':tgl_selesai <= tgl_selesai', [':tgl_selesai' => $saat_ini])
            ->one();

        $perhitungan_manual = array();

        if ($model->load(Yii::$app->request->post())){
        	$id_pengaturan =  $model->id_pengaturan;
        	$id_jurusan =  $model->id_jurusan;

        	//Ambil Data Pengaturan
            $modelPengaturan = Pengaturan::find()
            ->where(['id_pengaturan' => $id_pengaturan])
            ->one();

            $data_siswa_tahun = true;
            $data_siswa_kelas = true;

            if(!empty($modelPengaturan)){
                //DATA BOBOT TIAP KRITERIA
                $bobotQuery = new \yii\db\Query;
                $bobotQuery->select(['*'])  
                        ->from('pengaturan_kriteria pk')
                        ->join( 'JOIN', 
                            'kriteria k',
                            'pk.id_kriteria = k.id_kriteria'
                        ); 
                $command = $bobotQuery->createCommand();
                $dataBobot = $command->queryAll();

                $bobot = array();
                $kriteria = array();
                foreach ($dataBobot as $key => $dtBobot) {
                    $bobot[$dtBobot['kode_kriteria']] = $dtBobot['bobot'];
                    $kriteria[$dtBobot['kode_kriteria']] = $dtBobot['nama_kriteria'];
                }

                //Ambil Data Jurusan
                $jurusanQuery = Jurusan::find()
                ->where(':id_jurusan = id_jurusan', [':id_jurusan' => $id_jurusan])
                ->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();


                $jurusan = array();
                $siswa = array();
                if(!empty($jurusanQuery)){
                    foreach ($jurusanQuery as $keyJur => $dtJur) {
                        $jurusan[$dtJur->id_jurusan] = $dtJur->nama_jurusan;

                        //Ambil Data Siswa Sesuai Tahun Ajaran dan Jurusan
                        $modelSiswa = Siswa::find()
                        ->joinWith('nilaiUn', true)
                        ->where('id_pengaturan = :id_pengaturan', [':id_pengaturan' => $modelPengaturan->id_pengaturan])
                        ->andWhere('id_jurusan = :id_jurusan', [':id_jurusan' => $dtJur->id_jurusan])
                        ->andWhere('status_verifikasi = :status', [':status' => 'Sudah'])
                        //->andWhere(['is', 'nisn' , new \yii\db\Expression('null')])
                        ->orderBy('nama_siswa')
                        ->all();

                        if(!empty($modelSiswa)){
                            $data_siswa_tahun = false;

                            $dt_siswa = array();
                            //Data Nilai Siswa Tahun Ajaran dan Jurusan
                            $siswa_un_V = array();
                            $siswa_un_H = array();

                            foreach ($modelSiswa as $key => $dtSiswa) {
                    			$siswa[$dtJur->id_jurusan]['nama'][$dtSiswa->id_siswa] = $dtSiswa->nama_siswa;
                                $dt_siswa[$dtSiswa->id_siswa] = $dtSiswa->id_siswa;
                                $dtSiswaNilai = $dtSiswa['nilaiUn'][0];
                                
                                $nilaiUNQuery = new \yii\db\Query;
                                $nilaiUNQuery->select(['*'])  
                                        ->from('detail_nilai_un dnu')
                                        ->join( 'JOIN', 
                                            'kriteria k',
                                            'dnu.id_kriteria = k.id_kriteria'
                                        )
                                        ->where('id_un = :id_un', [':id_un' => $dtSiswaNilai->id_un]); 
                                $commandUN = $nilaiUNQuery->createCommand();
                                $dataNilaiUN = $commandUN->queryAll();

                                foreach ($dataNilaiUN as $key => $dtNilaiUN) {
                                    //Horizontal
                                    $siswa_un_H[$dtSiswa->id_siswa][$dtNilaiUN['kode_kriteria']] = $dtNilaiUN['nilai'];
                                    //Vertical
                                    $siswa_un_V[$dtNilaiUN['kode_kriteria']][$dtSiswa->id_siswa] = $dtNilaiUN['nilai'];
                                }
                            }

                            
                            $siswa[$dtJur->id_jurusan]['nilai'] = $siswa_un_H;

                            
                            //Matrik R
                            $matrik_R_H = array();
                            $matrik_R_V = array();
                            foreach ($siswa_un_V as $key_nilai => $arrSiswa) {
                                $max_r = max($arrSiswa);
                                foreach ($arrSiswa as $id_siswa => $val) {
                                    //Horizontal
                                    $matrik_R_H[$id_siswa][$key_nilai] = $val/$max_r;
                                    //Vertical
                                    $matrik_R_V[$key_nilai][$id_siswa] = $val/$max_r;
                                }
                            }


                            $matrikR[$dtJur->id_jurusan] = $matrik_R_H;


                            //Preverensi tiap Alternatif 
                            $pa = array();
                            foreach ($matrik_R_H as $id_siswa => $arrNilai) {
                                $kali = array();
                                foreach ($arrNilai as $key_nilai => $val) {
                                    $kali[$key_nilai] = $bobot[$key_nilai] * $val;
                                }

                                $pa[$id_siswa] = array_sum($kali);
                            }

                            //Pengurutan Ranking
                            arsort($pa);
                            //Penempatan Index untuk nanti pembagian di tiap kelas
                            $idx_kelas = 1;
                            $data_siswa = array();
                            foreach ($pa as $id_siswa => $nilai) {
                                $data_siswa[$idx_kelas]['id_siswa'] = $id_siswa;
                                $data_siswa[$idx_kelas]['nilai'] = $nilai;
                                $data_siswa[$idx_kelas]['ranking'] = $idx_kelas;
                                $idx_kelas++;
                            }
                            
                            //Cek Ranking sudah ada apa belum
                            $modelPerangkingan = Perangkingan::find()
                            ->where('id_pengaturan = :id_pengaturan', [':id_pengaturan' => $id_pengaturan])
                            ->one();

                            if(!empty($modelPerangkingan)){
                                //Ubah Waktu Prosesnya
                                $modelPerangkingan->tgl_perangkingan = date("Y-m-d H:i:s");
                            }else{
                                $modelPerangkingan = new Perangkingan();
                                $modelPerangkingan->id_pengaturan = $id_pengaturan;
                                $modelPerangkingan->tgl_perangkingan = date("Y-m-d H:i:s");
                            }
                            
                            //Ambil Data Kelas
                            $modelKelas = Kelas::find()
                            ->where('id_jurusan = :id_jurusan', [':id_jurusan' => $dtJur->id_jurusan])
                            ->orderBy('urutan')
                            ->all();

                            if(!empty($modelKelas)){
                                if($modelPerangkingan->save()){
                                    //Hapus Detail Rangking Sebelumnya
                                    DetailRanking::deleteAll(['id_ranking' => $modelPerangkingan->id_ranking]);
                                    $jmlCalonSiswa = count($data_siswa);
                                    $idx_kapasitas = 1;
                                    //Data Kelas
                                    foreach ($modelKelas as $key_kelas => $arrKelas) {
                                        //Kapasitas tiap Kelas
                                        $kapasitas = $arrKelas->kapasitas;
                                        $batas = $kapasitas+$idx_kapasitas-1;
                                        foreach(range($idx_kapasitas,$batas) as $v){
                                            //Jika Sudah Tidak Ada Calon Siswa Break;
                                            if($v>$jmlCalonSiswa){
                                                break;
                                            }

                                            //INSERT DETAIL RANKING
                                            $modelDetailRanking = new DetailRanking();
                                            $modelDetailRanking->id_siswa = $data_siswa[$v]['id_siswa'];
                                            $modelDetailRanking->id_kelas = $arrKelas->id_kelas;
                                            $modelDetailRanking->id_ranking = $modelPerangkingan->id_ranking;
                                            $modelDetailRanking->nilai = $data_siswa[$v]['nilai'];
                                            $modelDetailRanking->urutan = $data_siswa[$v]['ranking'];
                                            $modelDetailRanking->save();
                                            //echo $v.'= '. $kapasitas .' => '.$batas."<br />";
                                        }
                                        $idx_kapasitas += $kapasitas;
                                    }
                                }
                                
                            }else{
                                $data_siswa_kelas = false;
                                
                            }
                            
                        }
                    }
                    
                }

                //SIMPAN PERHITUNGAN MANUAL DALAM ARRAY
                $perhitungan_manual['bobot'] = $bobot;
                $perhitungan_manual['kriteria'] = $kriteria;
                $perhitungan_manual['jurusan'] = $jurusan;
                $perhitungan_manual['siswa'] = $siswa;
                $perhitungan_manual['matrikR'] = $matrikR;
            }
        }

        return $this->render('index', [
            'model' => $model,
            'modelPengaturan' => $pengaturanQuery,
            'modelJurusan' => $jurusanQuery,
            'modelSaatini' => $modelPengaturan,
            'perhitungan_manual' => $perhitungan_manual,
        ]);
    }


    /**
     * Creates a new Perangkingan model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionProses()
    {
        $request = Yii::$app->request;
        if(!empty($request->post('DynamicModel'))){
            $id_pengaturan = $request->post('DynamicModel')['id_pengaturan'];
            
            //Ambil Data Pengaturan
            $modelPengaturan = Pengaturan::find()
            ->where(['id_pengaturan' => $id_pengaturan])
            ->one();

            $data_siswa_tahun = true;
            $data_siswa_kelas = true;

            if(!empty($modelPengaturan)){
                //DATA BOBOT TIAP KRITERIA
                $bobotQuery = new \yii\db\Query;
                $bobotQuery->select(['*'])  
                        ->from('pengaturan_kriteria pk')
                        ->join( 'JOIN', 
                            'kriteria k',
                            'pk.id_kriteria = k.id_kriteria'
                        ); 
                $command = $bobotQuery->createCommand();
                $dataBobot = $command->queryAll();

                $bobot = array();
                foreach ($dataBobot as $key => $dtBobot) {
                    $bobot[$dtBobot['kode_kriteria']] = $dtBobot['bobot'];
                }


                //Ambil Data Jurusan
                $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();

                if(!empty($jurusanQuery)){
                    foreach ($jurusanQuery as $keyJur => $dtJur) {
                        //Ambil Data Siswa Sesuai Tahun Ajaran dan Jurusan

                        $modelSiswa = Siswa::find()
                        ->joinWith('nilaiUn', true)
                        ->where('id_pengaturan = :id_pengaturan', [':id_pengaturan' => $modelPengaturan->id_pengaturan])
                        ->andWhere('id_jurusan = :id_jurusan', [':id_jurusan' => $dtJur->id_jurusan])
                        ->andWhere('status_verifikasi = :status', [':status' => 'Sudah'])
                        //->andWhere(['is', 'nisn' , new \yii\db\Expression('null')])
                        ->all();

                        if(!empty($modelSiswa)){
                            $data_siswa_tahun = false;

                            $dt_siswa = array();
                            //Data Nilai Siswa Tahun Ajaran dan Jurusan
                            $siswa_un_V = array();
                            $siswa_un_H = array();

                            foreach ($modelSiswa as $key => $dtSiswa) {
                    
                                $dt_siswa[$dtSiswa->id_siswa] = $dtSiswa->id_siswa;
                                
                                $dtSiswaNilai = $dtSiswa['nilaiUn'][0];
                                
                                $nilaiUNQuery = new \yii\db\Query;
                                $nilaiUNQuery->select(['*'])  
                                        ->from('detail_nilai_un dnu')
                                        ->join( 'JOIN', 
                                            'kriteria k',
                                            'dnu.id_kriteria = k.id_kriteria'
                                        )
                                        ->where('id_un = :id_un', [':id_un' => $dtSiswaNilai->id_un]); 
                                $commandUN = $nilaiUNQuery->createCommand();
                                $dataNilaiUN = $commandUN->queryAll();

                                foreach ($dataNilaiUN as $key => $dtNilaiUN) {
                                    //Horizontal
                                    $siswa_un_H[$dtSiswa->id_siswa][$dtNilaiUN['kode_kriteria']] = $dtNilaiUN['nilai'];
                                    //Vertical
                                    $siswa_un_V[$dtNilaiUN['kode_kriteria']][$dtSiswa->id_siswa] = $dtNilaiUN['nilai'];
                                }
                            }

                            
                            //Matrik R
                            $matrik_R_H = array();
                            $matrik_R_V = array();
                            foreach ($siswa_un_V as $key_nilai => $arrSiswa) {
                                $max_r = max($arrSiswa);
                                foreach ($arrSiswa as $id_siswa => $val) {
                                    //Horizontal
                                    $matrik_R_H[$id_siswa][$key_nilai] = $val/$max_r;
                                    //Vertical
                                    $matrik_R_V[$key_nilai][$id_siswa] = $val/$max_r;
                                }
                            }


                            //Preverensi tiap Alternatif 
                            $pa = array();
                            foreach ($matrik_R_H as $id_siswa => $arrNilai) {
                                $kali = array();
                                foreach ($arrNilai as $key_nilai => $val) {
                                    $kali[$key_nilai] = $bobot[$key_nilai] * $val;
                                }

                                $pa[$id_siswa] = array_sum($kali);
                            }

                            //Pengurutan Ranking
                            arsort($pa);
                            //Penempatan Index untuk nanti pembagian di tiap kelas
                            $idx_kelas = 1;
                            $data_siswa = array();
                            foreach ($pa as $id_siswa => $nilai) {
                                $data_siswa[$idx_kelas]['id_siswa'] = $id_siswa;
                                $data_siswa[$idx_kelas]['nilai'] = $nilai;
                                $data_siswa[$idx_kelas]['ranking'] = $idx_kelas;
                                $idx_kelas++;
                            }

                            //Cek Ranking sudah ada apa belum
                            $modelPerangkingan = Perangkingan::find()
                            ->where('id_pengaturan = :id_pengaturan', [':id_pengaturan' => $id_pengaturan])
                            ->one();

                            if(!empty($modelPerangkingan)){
                                //Ubah Waktu Prosesnya
                                $modelPerangkingan->tgl_perangkingan = date("Y-m-d H:i:s");
                            }else{
                                $modelPerangkingan = new Perangkingan();
                                $modelPerangkingan->id_pengaturan = $id_pengaturan;
                                $modelPerangkingan->tgl_perangkingan = date("Y-m-d H:i:s");
                            }
                            
                            //Ambil Data Kelas
                            $modelKelas = Kelas::find()
                            ->where('id_jurusan = :id_jurusan', [':id_jurusan' => $dtJur->id_jurusan])
                            ->orderBy('urutan')
                            ->all();

                            if(!empty($modelKelas)){
                                if($modelPerangkingan->save()){
                                    //Hapus Detail Rangking Sebelumnya
                                    DetailRanking::deleteAll(['id_ranking' => $modelPerangkingan->id_ranking]);
                                    $jmlCalonSiswa = count($data_siswa);
                                    $idx_kapasitas = 1;
                                    //Data Kelas
                                    foreach ($modelKelas as $key_kelas => $arrKelas) {
                                        //Kapasitas tiap Kelas
                                        $kapasitas = $arrKelas->kapasitas;
                                        $batas = $kapasitas+$idx_kapasitas-1;
                                        foreach(range($idx_kapasitas,$batas) as $v){
                                            //Jika Sudah Tidak Ada Calon Siswa Break;
                                            if($v>$jmlCalonSiswa){
                                                break;
                                            }

                                            //INSERT DETAIL RANKING
                                            $modelDetailRanking = new DetailRanking();
                                            $modelDetailRanking->id_siswa = $data_siswa[$v]['id_siswa'];
                                            $modelDetailRanking->id_kelas = $arrKelas->id_kelas;
                                            $modelDetailRanking->id_ranking = $modelPerangkingan->id_ranking;
                                            $modelDetailRanking->nilai = $data_siswa[$v]['nilai'];
                                            $modelDetailRanking->urutan = $data_siswa[$v]['ranking'];
                                            $modelDetailRanking->save();
                                            //echo $v.'= '. $kapasitas .' => '.$batas."<br />";
                                        }
                                        $idx_kapasitas += $kapasitas;
                                    }
                                }
                                
                            }else{
                                $data_siswa_kelas = false;
                                
                            }

                            
                            
                        }
                    }
                    
                }
            }

            if($data_siswa_tahun){
                //Jika Tidak Ditemukan Siswa di Tahun Ajaran dan Jurusan Tersebut
                Yii::$app->session->setFlash('error', 'Tahun Ajaran '.$modelPengaturan->tahun_ajaran.' belum ada calon siswa');
            }else if($data_siswa_kelas){
                Yii::$app->session->setFlash('success', 'Perangkingan Calon Siswa Berhasil');
            }else{
                Yii::$app->session->setFlash('error', 'Ada Kelas belum diatur');
            }
            
        }

        //echo "<pre>";
        //print_r($request);
        //print_r($modelSiswa);
        //echo "</pre>";

        return Yii::$app->getResponse()->redirect(['perangkingan/index']);
    }

    /**
     * Finds the Perangkingan model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Perangkingan the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Perangkingan::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
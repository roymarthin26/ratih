<?php

namespace backend\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use backend\models\Jurusan;
use backend\models\Kelas;

class KelasController extends Controller
{
	/**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function beforeAction($action) {
        $this->enableCsrfValidation = false;
        return parent::beforeAction($action);
    }

    /**
     * Lists all Kelas models.
     * @return mixed
     */
    public function actionIndex()
    {
        $kelasQuery = Kelas::find()->indexBy('id_kelas')->orderBy('id_jurusan, urutan')->all();

        return $this->render('index', [
            'dataProvider' => $kelasQuery,
        ]);
    }


    /**
     * Creates a new Kelas model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Kelas();
        
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Data kelas berhasil disimpan');
            return $this->redirect(['index']);
        } else {
            $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();
            return $this->render('create', [
                'model' => $model,
                'dtJurusan' => $jurusanQuery,
            ]);
        }
    }

    /**
     * Updates an existing Kelas model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Data kelas berhasil diubah');
            return $this->redirect(['index']);
        } else {
            $jurusanQuery = Jurusan::find()->indexBy('id_jurusan')->orderBy('nama_jurusan')->all();
            return $this->render('update', [
                'model' => $model,
                'dtJurusan' => $jurusanQuery,
            ]);
        }
    }

     /**
     * Deletes an existing Kelas model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
    public function actionDelete()
    {
		if(!empty($_POST['pilih'])){
            $pilih = $_POST['pilih'];
            foreach ($pilih as $id_kelas => $value) {
                $this->findModel($id_kelas)->delete();
            }
        }
        Yii::$app->session->setFlash('success', 'Data kelas berhasil dihapus');
        return $this->redirect(['index']);
    }

    /**
     * Finds the Kelas model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Kelas the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Kelas::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
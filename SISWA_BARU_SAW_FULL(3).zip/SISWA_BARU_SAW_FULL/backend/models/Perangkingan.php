<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "ranking".
 *
 * @property integer $id_ranking
 * @property string $id_pengaturan
 * @property string $tgl_perangkingan
 *
 */
class Perangkingan extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'ranking';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_pengaturan'], 'required'],
            [['id_pengaturan'], 'unique'],
            [['id_pengaturan'], 'exist', 'skipOnError' => true, 'targetClass' => Pengaturan::className(), 'targetAttribute' => ['id_pengaturan' => 'id_pengaturan']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_ranking' => 'ID Ranking',
            'id_pengaturan' => 'Pengaturan',
            'tgl_perangkingan' => 'Tanggal Perangkingan',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDetailRanking()
    {
        return $this->hasMany(DetailRanking::className(), ['id_ranking' => 'id_ranking']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPengaturan()
    {
        return $this->hasOne(Pengaturan::className(), ['id_pengaturan' => 'id_pengaturan']);
    }
}

<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "nilai_un".
 *
 * @property integer $id_un
 * @property integer $id_siswa
 * @property integer $scan_bukti
 *
 */
class Nilaiuan extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'nilai_un';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_siswa'], 'required'],
            [['id_siswa'], 'integer'],
            [['id_siswa'], 'exist', 'skipOnError' => true, 'targetClass' => Siswa::className(), 'targetAttribute' => ['id_siswa' => 'id_siswa']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_siswa' => 'ID Siswa',
            'scan_bukti' => 'Scan Bukti Nilai',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSiswa()
    {
        return $this->hasOne(Siswa::className(), ['id_siswa' => 'id_siswa']);
    }
}

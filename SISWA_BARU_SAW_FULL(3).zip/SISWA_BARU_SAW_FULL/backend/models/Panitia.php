<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "panitia".
 *
 * @property integer $id_panitia
 * @property string $username
 * @property string $password
 *
 */
class Panitia extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'panitia';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['username', 'password'], 'required'],
            [['username'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_panitia' => 'ID Panitia',
            'username' => 'Username',
            'password' => 'Password',
        ];
    }
}

<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kelas".
 *
 * @property integer $id_kelas
 * @property integer $id_jurusan
 * @property string $nama_kelas
 *
 */
class Kelas extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'kelas';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nama_kelas', 'id_jurusan', 'kapasitas', 'urutan'], 'required'],
            [['nama_kelas'], 'string'],
            [['kapasitas', 'urutan'], 'integer'],
            [['id_jurusan', 'nama_kelas'], 'unique', 'targetAttribute' => ['id_jurusan', 'nama_kelas'], 'message' => 'Data sudah ada sebelumnya'],
            [['id_jurusan', 'urutan'], 'unique', 'targetAttribute' => ['id_jurusan', 'urutan'], 'message' => 'Data sudah ada sebelumnya'],
            [['id_jurusan'], 'exist', 'skipOnError' => true, 'targetClass' => Jurusan::className(), 'targetAttribute' => ['id_jurusan' => 'id_jurusan']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_kelas' => 'ID Kelas',
            'id_jurusan' => 'ID Jurusan',
            'nama_kelas' => 'Nama Kelas',
            'kapasitas' => 'Kapasitas',
            'urutan' => 'Urutan',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getJurusan()
    {
        return $this->hasOne(Jurusan::className(), ['id_jurusan' => 'id_jurusan']);
    }
}

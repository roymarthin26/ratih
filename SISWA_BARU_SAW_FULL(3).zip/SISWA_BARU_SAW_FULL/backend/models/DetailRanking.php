<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "detail_ranking".
 *
 * @property integer $id_siswa
 * @property integer $id_ranking
 * @property integer $nilai
 * @property integer $urutan
 *
 */
class DetailRanking extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'detail_ranking';
    }

    public static function primaryKey()
    {
        return ['id_siswa', 'id_ranking'];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_siswa', 'id_ranking', 'nilai', 'urutan'], 'required'],
            [['urutan'], 'integer'],
            [['id_siswa'], 'exist', 'skipOnError' => true, 'targetClass' => Siswa::className(), 'targetAttribute' => ['id_siswa' => 'id_siswa']],
            [['id_ranking'], 'exist', 'skipOnError' => true, 'targetClass' => Perangkingan::className(), 'targetAttribute' => ['id_ranking' => 'id_ranking']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_siswa' => 'ID Siswa',
            'id_ranking' => 'ID Perangkingan',
            'nilai' => 'Nilai',
            'urutan' => 'Urutan',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSiswa()
    {
        return $this->hasOne(Siswa::className(), ['id_siswa' => 'id_siswa']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPerangkingan()
    {
        return $this->hasOne(Perangkingan::className(), ['id_ranking' => 'id_ranking']);
    }

    public function getKelas()
    {
        return $this->hasOne(Kelas::className(), ['id_kelas' => 'id_kelas']);
    }
}

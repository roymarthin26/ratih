<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "pengaturan".
 *
 * @property integer $id_pengaturan
 * @property string $tahun_ajaran
 * @property string $tgl_mulai
 * @property string $tgl_selesai
 *
 */
class Pengaturan extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'pengaturan';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tahun_ajaran', 'tgl_mulai', 'tgl_selesai'], 'required'],
            [['tahun_ajaran'], 'string'],
            [['tahun_ajaran'], 'unique'],
            [['tgl_mulai', 'tgl_selesai'], 'date', 'format' => 'php:Y-m-d'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_pengaturan' => 'ID Pengaturan',
            'tahun_ajaran' => 'Tahun Ajaran',
            'tgl_mulai' => 'Tanggal Mulai',
            'tgl_selesai' => 'Tanggal Selesai',
        ];
    }
}

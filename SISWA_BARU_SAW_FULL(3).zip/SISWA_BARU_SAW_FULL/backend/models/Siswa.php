<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "siswa".
 *
 * @property integer $id_siswa
 * @property string $id_pengaturan
 * @property string $nisn
 * @property string $nama_siswa
 * @property string $nama_orangtua
 * @property string $tempat_lahir
 * @property string $tgl_lahir
 * @property string $jenis_kelamin
 * @property string $agama
 * @property string $alamat
 *
 */
class Siswa extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'siswa';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_pengaturan', 'id_jurusan', 'nisn', 'nama_siswa', 'nama_orangtua', 'tempat_lahir', 'tgl_lahir', 'jenis_kelamin', 'agama', 'alamat'], 'required'],
            [['nisn'], 'integer'],
            [['nama_siswa', 'nama_orangtua', 'tempat_lahir', 'agama', 'alamat'], 'string'],
            [['tgl_lahir'], 'date', 'format' => 'php:Y-m-d'],
            [['nama_siswa', 'nama_orangtua'], 'string', 'max' => 50],
            [['id_jurusan'], 'exist', 'skipOnError' => true, 'targetClass' => Jurusan::className(), 'targetAttribute' => ['id_jurusan' => 'id_jurusan']],
            [['id_pengaturan'], 'exist', 'skipOnError' => true, 'targetClass' => Pengaturan::className(), 'targetAttribute' => ['id_pengaturan' => 'id_pengaturan']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_siswa' => 'ID Siswa',
            'id_jurusan' => 'Jurusan',
            'id_pengaturan' => 'Tahun Ajaran',
            'nama_siswa' => 'Nama Siswa',
            'nama_orangtua' => 'Nama Ortu',
            'tempat_lahir' => 'Tempat Lahir',
            'tgl_lahir' => 'Tanggal Lahir',
            'jenis_kelamin' => 'Jenis Kelamin',
            'agama' => 'Agama',
            'alamat' => 'Alamat',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNilaiUn()
    {
        return $this->hasMany(NilaiUan::className(), ['id_siswa' => 'id_siswa']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getJurusan()
    {
        return $this->hasOne(Jurusan::className(), ['id_jurusan' => 'id_jurusan']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPengaturan()
    {
        return $this->hasOne(Pengaturan::className(), ['id_pengaturan' => 'id_pengaturan']);
    }
}

<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kriteria".
 *
 * @property integer $id_kriteria
 * @property string $kode_kriteria
 * @property string $nama_kriteria
 *
 */
class Kriteria extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'kriteria';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['kode_kriteria', 'nama_kriteria'], 'required'],
            [['kode_kriteria', 'nama_kriteria'], 'string'],
            [['kode_kriteria'], 'unique'],
            [['nama_kriteria'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_kriteria' => 'ID Kriteria',
            'kode_kriteria' => 'Kode Kriteria',
            'nama_kriteria' => 'Nama Kriteria',
        ];
    }
}

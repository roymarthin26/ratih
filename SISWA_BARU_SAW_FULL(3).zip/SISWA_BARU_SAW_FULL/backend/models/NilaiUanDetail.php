<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "detail_nilai_un".
 *
 * @property integer $id_un
 * @property integer $id_kriteria
 * @property integer $nilai
 *
 */
class NilaiUanDetail extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'detail_nilai_un';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_un', 'id_kriteria', 'nilai'], 'required'],
            [['id_un', 'id_kriteria', 'nilai'], 'integer'],
            [['id_un'], 'exist', 'skipOnError' => true, 'targetClass' => Nilaiuan::className(), 'targetAttribute' => ['id_un' => 'id_un']],
            [['id_kriteria'], 'exist', 'skipOnError' => true, 'targetClass' => Kriteria::className(), 'targetAttribute' => ['id_kriteria' => 'id_kriteria']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_un' => 'UN',
            'id_kriteria' => 'Kriteria',
            'nilai' => 'Nilai',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUAN()
    {
        return $this->hasOne(Nilaiuan::className(), ['id_un' => 'id_un']);
    }
    public function getKriteria()
    {
        return $this->hasOne(Kriteria::className(), ['id_kriteria' => 'id_kriteria']);
    }
}

<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "pengaturan_kriteria".
 *
 * @property integer $id_pk
 * @property integer $id_pengaturan
 * @property integer $id_kriteria
 * @property integer $bobot
 *
 */
class PengaturanKriteria extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'pengaturan_kriteria';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_pengaturan', 'id_kriteria', 'bobot'], 'required'],
            [['id_pengaturan', 'id_kriteria', 'bobot'], 'integer'],
            [['id_pengaturan', 'id_kriteria'], 'unique', 'targetAttribute' => ['id_pengaturan', 'id_kriteria'], 'message' => 'Data sudah ada sebelumnya'],
            [['id_pengaturan'], 'exist', 'skipOnError' => true, 'targetClass' => Pengaturan::className(), 'targetAttribute' => ['id_pengaturan' => 'id_pengaturan']],
            [['id_kriteria'], 'exist', 'skipOnError' => true, 'targetClass' => Kriteria::className(), 'targetAttribute' => ['id_kriteria' => 'id_kriteria']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_pengaturan' => 'Tahun Ajaran',
            'id_kriteria' => 'Kriteria',
            'bobot' => 'Bobot',
        ];
    }

    public function getPengaturan()
    {
        return $this->hasOne(Pengaturan::className(), ['id_pengaturan' => 'id_pengaturan']);
    }

    public function getKriteria()
    {
        return $this->hasOne(Kriteria::className(), ['id_kriteria' => 'id_kriteria']);
    }
}

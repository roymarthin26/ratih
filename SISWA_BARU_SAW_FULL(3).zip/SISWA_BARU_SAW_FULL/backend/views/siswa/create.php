<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Siswa */

if(!empty($modelPengaturan)){
	$ta = "Tahun Ajaran ".$modelPengaturan->tahun_ajaran;
}else{
	$ta = "";
}

$this->title = 'Siswa Tambah '.$ta;
$this->params['breadcrumbs'][] = ['label' => 'Siswa', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

?>
<div class="card">
    <div class="card-body">
    	<h4 class="card-title"><?= Html::encode($this->title) ?></h4>
    	<?php
    	if($ta=""){
    	?>
    	<div class="row">
		  <div class="col-lg-12">
		    <div class="card card-small mb-4">
		      <div class="card-header border-bottom">
		        <h6 class="m-0"><?= Html::encode($this->title) ?></h6>
		      </div>
		      <div class="card-body p-0 pb-3 text-center">
		        <p>Data pengaturan belum diatur, silahkan mengatur Tahun Ajaran saat ini <a href="<?= Yii::$app->request->baseUrl;?>/pengaturan">disini</a></p>
		      </div>
		  </div>
		</div>
    	<?php
    	}else{
    	?>
    	<?= $this->render('_form', [
	        'model' => $model,
	        'modelUn' => $modelUn,
	        'modelJurusan' => $modelJurusan,
	        'modelKriteria' => $modelKriteria,
	        'modelNilai' => $modelNilai,
	    ]) ?>
    	<?php
    	}
    	?>
	    
	</div>
</div>

<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model backend\models\Siswa */

$this->title = 'Siswa Import';
$this->params['breadcrumbs'][] = ['label' => 'Siswa', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

$dtJurusan = ArrayHelper::map($modelJurusan,'id_jurusan','nama_jurusan');
$dtPengaturan = ArrayHelper::map($modelPengaturan,'id_pengaturan','tahun_ajaran');
?>
<div class="card">
    <div class="card-body">
    	<h4 class="card-title"><?= Html::encode($this->title) ?></h4>

	    <div class="row">
		  <div class="col-lg-12">
		    <div class="card card-small mb-4">
		      <div class="card-header border-bottom">
		        <h6 class="m-0"><?= Html::encode($this->title) ?></h6>
		      </div>
		      	<?php $form = ActiveForm::begin([
				    'options' => ['enctype' => 'multipart/form-data'],
				    'fieldConfig' => [
		              'options' => [
		                  'tag' => false,
		              ],
		          ],
				]); ?>
				<?php // echo $model->id_pengaturan;?>
				<?php // echo $model->id_siswa;?>

		      <ul class="list-group list-group-flush">
		        <li class="list-group-item p-3">
		          <div class="row">
		            <div class="col-sm-12 col-md-6">
		              <div class="form-group">
		                <div class="input-group mb-3">
		                  <div class="input-group-prepend">
		                    <span class="input-group-text" for="id_jurusan">Nama Jurusan</span>
		                  </div>
		                  <?php
		                  echo $form->field($model, 'id_jurusan')
		                  ->dropDownList($dtJurusan,
		                      ['prompt'=>'-- Pilih Jurusan --']    // options
		                  )->label(false);
		                  ?>
		                </div>
		              </div>
		            </div>
		            <div class="col-sm-12 col-md-6">
		              
		            </div>
		            <div class="col-sm-12 col-md-6">
		              <div class="form-group">
		                <div class="input-group mb-3">
		                  <div class="input-group-prepend">
		                    <span class="input-group-text" for="id_pengaturan">Tahun Ajaran</span>
		                  </div>
		                  <?php
		                  echo $form->field($model, 'id_pengaturan')
		                  ->dropDownList($dtPengaturan,
		                      ['prompt'=>'-- Pilih Tahun Ajaran --']    // options
		                  )->label(false);
		                  ?>
		                </div>
		              </div>
		            </div>
		            <div class="col-sm-12 col-md-6">
		              
		            </div>
		            <div class="col-sm-12 col-md-6">
		              <div class="form-group">
		                <div class="input-group mb-3">
		                  <div class="input-group-prepend">
		                    <span class="input-group-text" for="file">File Data Siswa</span>
		                  </div>
		                  <input class="form-control" name="file" type="file">
		                </div>
		              </div>
		            </div>
		            <div class="col-sm-12 col-md-6">
		              
		            </div>
		            <div class="col-sm-12 col-md-12">
		              <hr />
		              <strong class="text-muted d-block my-2"></strong>
		              <div class="row mb-3">
		                <div class="col text-center">
		                  <a href="<?= Yii::$app->request->baseUrl;?>/siswa"><button type="button" class="mb-2 btn btn-sm btn-warning mr-1"><i class="material-icons">&#xE5C4;</i> Kembali</button></a>
		                  <?= Html::submitButton('<i class="material-icons">save</i> Import', ['class' => 'mb-2 btn btn-sm btn-primary mr-1']) ?>
		                </div>
		              </div>
		            </div>
		          </div>
		        </li>
		      </ul>
		      <?php ActiveForm::end(); ?>
		    </div>
		  </div>
		</div>
	</div>

    <div class="card-body">
    	<h4 class="card-title">Contoh file yang di import</h4>
    	<p>Pastikan nomor awal calon siswa posisi baris ke <code>30</code></p>
    	<p>Kriteria yang wajib ada adalah <b>C1</b> = <code>MATEMATIKA</code>, <b>C2</b> = <code>IPA</code>, <b>C3</b> = <code>BAHASA INDONESIA</code>, <b>C4</b> = <code>BAHASA INGGRIS</code>, <b>C5</b> = <code>PRESTASI</code></p>
	    <div class="row">
		  <div class="col-lg-12">
			<img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 100%;" src="<?= Yii::$app->request->baseUrl.'/images/IMPORT.JPG';?>" alt="Shards Dashboard">
			</div>
		</div>
	</div>
</div>
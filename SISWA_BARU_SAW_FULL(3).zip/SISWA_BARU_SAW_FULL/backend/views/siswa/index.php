<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

if(!empty($modelSaatini->tahun_ajaran)){

/* @var $this yii\web\View */
$ta = $modelSaatini->tahun_ajaran;
$this->title = 'Data Calon Siswa';
$this->params['breadcrumbs'][] = $this->title;

$dtPengaturan = ArrayHelper::map($modelPengaturan,'id_pengaturan','tahun_ajaran');
$dtJurusan = ArrayHelper::map($modelJurusan,'id_jurusan','nama_jurusan');
?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Data Calon Siswa</span>
  </div>
</div>
<!-- End Page Header -->

<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Data Calon Siswa</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <fieldset>
        <?php if (Yii::$app->session->hasFlash('success')): ?>
            <div class="alert alert-success alert-dismissable">
             <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
             <h4><i class="icon fa fa-check"></i>Berhasil!</h4>
             <?= Yii::$app->session->getFlash('success') ?>
            </div>
        <?php endif; ?>
        <strong class="text-muted d-block my-2"></strong>
        <div class="row mb-3">
          <div class="col">
            <?php $form = ActiveForm::begin([
             'fieldConfig' => [
                  'options' => [
                      'tag' => false,
                  ],
              ],
            ]); ?>
            <div class="col-sm-12 col-md-6">
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="id_pengaturan">Tahun Ajaran</span>
                  </div>
                  <?php
                  echo $form->field($model, 'id_pengaturan')
                  ->dropDownList($dtPengaturan,
                      ['prompt'=>'-- Pilih Tahun Ajaran --']    // options
                  )->label(false);
                  ?>
                </div>
              </div>
            </div>

            <div class="col-sm-12 col-md-6">
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="id_jurusan">Jurusan</span>
                  </div>
                  <?php
                  echo $form->field($model, 'id_jurusan')
                  ->dropDownList($dtJurusan,
                      ['prompt'=>'-- Pilih Jurusan --']    // options
                  )->label(false);
                  ?>
                </div>
              </div>
            </div>

            <div class="col-sm-12 col-md-12">
              <hr />
              <strong class="text-muted d-block my-2"></strong>
              <div class="row mb-3">
                <div class="col text-center">
                  
                  <?= Html::submitButton('<i class="material-icons">control_point</i> Lihat', ['class' => 'mb-2 btn btn-sm btn-warning mr-1']) ?>
                </div>
              </div>
            </div>

            <?php ActiveForm::end(); ?>
          </div>
        </div>
        <hr />
        <div class="col">
          <form method="post" action="<?= Yii::$app->request->baseUrl;?>/siswa/delete" onsubmit="return hapus()">
          <input type="hidden" name="_csrf" value="<?=Yii::$app->request->getCsrfToken()?>" />

          <table class="table mb-0" id="example">
            <thead class="bg-light">
              <tr>
                <th scope="col" class="border-0" width="90px">
                  <div class="custom-control custom-checkbox mb-1">
                    <input type="checkbox" class="custom-control-input" id="checkAll"/>
                    <label class="custom-control-label" for="checkAll">No</label>
                  </div>
                </th>
                <th scope="col" class="border-0">Jurusan</th>
                <th scope="col" class="border-0">Identitas Siswa</th>
                <th scope="col" class="border-0">Nama Siswa</th>
                <th scope="col" class="border-0">TTl</th>
                <th scope="col" class="border-0">Jenis Kelamin</th>
                <th scope="col" class="border-0">Agama</th>
                <th scope="col" class="border-0">Alamat</th>
                <th scope="col" class="border-0">Status</th>
                <th scope="col" class="border-0">Aksi</th>
              </tr>
            </thead>
            <tbody>
            </tbody>
          </table>

          <!-- Small Buttons -->
            <hr />
            <strong class="text-muted d-block my-2"></strong>
            <div class="row mb-3">
              <div class="col">
                <button type="submit" name="hapus" class="mb-2 btn btn-sm btn-danger mr-1"><i class="material-icons">delete_forever</i> Hapus Terpilih</button>
                <a href="<?= Yii::$app->request->baseUrl;?>/siswa/create">
                <button type="button" class="mb-2 btn btn-sm btn-info mr-1"><i class="material-icons">control_point</i> Tambah Siswa</button>
                </a>
                
                <a href="<?= Yii::$app->request->baseUrl;?>/siswa/import">
                <button type="button" class="mb-2 btn btn-sm btn-success mr-1"><i class="material-icons">upload</i> Import Siswa</button>
                </a>
              </div>
            </div>
            <!-- / Small Buttons -->
          </form>
        </div>
        </fieldset>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});
</script>

<script type="text/javascript">
$(document).ready(function() {
  $('#example').DataTable({
    "processing": true,
    "ordering": true,
    "serverSide": true,
    "ajax": '<?php echo Yii::$app->request->baseUrl.'/siswa/ajax?ta='.$model->id_pengaturan.'&jur='.$model->id_jurusan;?>',
    "columnDefs": [{
      "targets": [0,9],
      "orderable": false
    }]
  });
} );
</script>

<?php
}else{
?>
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Data Calon Siswa</span>
  </div>
</div>
<!-- End Page Header -->
<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Data Calon Siswa</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <p>Data pengaturan belum diatur, silahkan mengatur Tahun Ajaran saat ini <a href="<?= Yii::$app->request->baseUrl;?>/pengaturan">disini</a></p>
      </div>
    </div>
  </div>
</div>
<?php  
}
?>
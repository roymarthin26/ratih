<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\Kategori */

$this->title = 'Update Siswa: ' . $model->nama_siswa;
$this->params['breadcrumbs'][] = ['label' => 'Kategori', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_siswa, 'url' => ['view', 'id' => $model->id_siswa]];
$this->params['breadcrumbs'][] = 'Update';
?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Ubah Data Calon Siswa</span>
  </div>
</div>
<!-- End Page Header -->

<?= $this->render('_form', [
    'model' => $model,
    'modelUn' => $modelUn,
    'modelJurusan' => $modelJurusan,
    'modelKriteria' => $modelKriteria,
	'modelNilai' => $modelNilai,
	'dataNilai' => $dataNilai,
]) ?>
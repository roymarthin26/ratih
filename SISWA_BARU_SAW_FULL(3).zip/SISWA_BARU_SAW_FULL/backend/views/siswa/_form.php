<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */

$dtJurusan = ArrayHelper::map($modelJurusan,'id_jurusan','nama_jurusan');
?>

<div class="row">
  <div class="col-lg-12">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0"><?= Html::encode($this->title) ?></h6>
      </div>
      	<?php $form = ActiveForm::begin([
		    'options' => [
		        'class' => ''
		     ]
		]); ?>
		<?php // echo $model->id_pengaturan;?>
		<?php // echo $model->id_siswa;?>

      <ul class="list-group list-group-flush">
        <li class="list-group-item p-3">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <strong class="text-muted d-block mb-2">Data Calon Siswa</strong>
              <div class="form-group">
                <div class="input-group mb-3">
                  
                  <?php
                  echo $form->field($model, 'id_jurusan')
                  ->dropDownList($dtJurusan,
                      ['prompt'=>'-- Pilih Jurusan --']    // options
                  );
                  ?>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group mb-3">
                  
                  <?= $form->field($model, 'nisn')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'nisn']) ?>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group mb-3">
                  
                  <?= $form->field($model, 'nama_siswa')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'nama_siswa']) ?>
              	</div>
              </div>
              <div class="form-group">
                <div class="input-group mb-3">
                  
                  <?= $form->field($model, 'nama_orangtua')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'nama_orangtua']) ?>
              	</div>
              </div>
              <div class="form-row">
                <div class="form-group col-md-7">
                  <div class="input-group mb-3">
                    <?= $form->field($model, 'tempat_lahir')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'tempat_lahir']) ?>
                  </div>
                </div>
                <div class="form-group col-md-5">
                  <?= $form->field($model, 'tgl_lahir')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'tgl_lahir', 'type' => 'date']) ?>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group mb-3">
                  
                  	<?php
                  	echo $form->field($model, 'jenis_kelamin')
      			        ->dropDownList(
      			            array("L"=>"Laki-Laki","P"=>"Perempuan"),           // Flat array ('id'=>'label')
      			            ['prompt'=>'']    // options
      			        );
      			        ?>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group mb-3">
                  
                  	<?php
                  	echo $form->field($model, 'agama')
      			        ->dropDownList(
      			            array("Islam"=>"Islam","Katolik"=>"Katolik","Kristen"=>"Kristen","Hindu"=>"Hindu","Budha"=>"Budha","Konghucu"=>"Konghucu"),           // Flat array ('id'=>'label')
      			            ['prompt'=>'']    // options
      			        );
      			        ?>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group mb-3">
                  
                  <?= $form->field($model, 'alamat')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'alamat']) ?>
              	</div>
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              <strong class="text-muted d-block mb-2">Nilai Calon Siswa</strong>
              <?php
              if(!empty($modelKriteria)){
                foreach ($modelKriteria as $dtKriteria) {
                  if(!empty($dataNilai[$dtKriteria->id_kriteria])){
                    $val = $dataNilai[$dtKriteria->id_kriteria];
                  }else{
                    $val = "";
                  }
              ?>
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="form-group required">
                    <label class="control-label" for="k<?php echo $dtKriteria->id_kriteria;?>"><?php echo $dtKriteria->nama_kriteria;?></label>
                  
                    <?= $form->field($modelNilai, 'id_kriteria['.$dtKriteria->id_kriteria.']')->textInput(['maxlength' => true, 'type'=>'number', 'min'=>0, 'max'=>100, 'class' => 'form-control', 'id' => 'k'.$dtKriteria->id_kriteria, 'value'=>$val])->label(false) ?>
                  </div>
                </div>
              </div>
              <?php
                }
              }
              ?>

              <?php
              if(!$model->isNewRecord){
              ?>
              <div class="form-group">
                <div class="input-group mb-3">
                  
                    <?php
                    echo $form->field($model, 'status_verifikasi')
                    ->dropDownList(
                        array("Belum"=>"Belum","Sudah"=>"Verifikasi","Tolak"=>"Tolak"),           // Flat array ('id'=>'label')
                        ['prompt'=>'']    // options
                    );
                    ?>
                </div>
              </div>

              <div class="form-group">
                <div class="input-group mb-3">
                  Bukti Scan Raport
                  <?php
                  if($modelUn->scan_bukti!=""){
                    echo Html::img(Yii::$app->urlManagerFrontend->baseUrl.'/uploads/'.$modelUn->scan_bukti, ['width' => '450px']);
                  }
                  ?>
                </div>
              </div>
              <?php
              }
              ?>
              
            </div>
            <div class="col-sm-12 col-md-12">
              <hr />
              <strong class="text-muted d-block my-2"></strong>
              <div class="row mb-3">
                <div class="col text-center">
                  <a href="<?= Yii::$app->request->baseUrl;?>/siswa"><button type="button" class="mb-2 btn btn-sm btn-warning mr-1"><i class="material-icons">&#xE5C4;</i> Kembali</button></a>
                  <?= Html::submitButton($model->isNewRecord ? '<i class="material-icons">save</i> Simpan' : '<i class="material-icons">save</i> Update', ['class' => $model->isNewRecord ? 'mb-2 btn btn-sm btn-info mr-1' : 'mb-2 btn btn-sm btn-primary mr-1']) ?>
                </div>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <?php ActiveForm::end(); ?>
    </div>
  </div>
</div>
<?php

use yii\helpers\Html;
use yii\grid\GridView;

if(!empty($modelPengaturan->tahun_ajaran)){

/* @var $this yii\web\View */
$ta = $modelPengaturan->tahun_ajaran;
$this->title = 'Home';
$this->params['breadcrumbs'][] = $this->title;
?>
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Dashboard</span>
    <h3 class="page-title">Pendaftar Tahun Ajaran <?php echo $ta;?></h3>
  </div>
</div>
<!-- End Page Header -->
<!-- Small Stats Blocks -->
<div class="row">
  <div class="col-lg col-md-6 col-sm-6 mb-4">
    <div class="stats-small stats-small--1 card card-small">
      <div class="card-body p-0 d-flex">
        <div class="d-flex flex-column m-auto">
          <div class="stats-small__data text-center">
            <span class="stats-small__label text-uppercase">Total</span>
            <h6 class="stats-small__value count my-3"><?php echo $modelTotalPendaftar;?></h6>
          </div>
          <div class="stats-small__data">
            <span class="stats-small__percentage stats-small__percentage--increase">100%</span>
          </div>
        </div>
        <canvas height="120" class="blog-overview-stats-small-1"></canvas>
      </div>
    </div>
  </div>
  <div class="col-lg col-md-6 col-sm-6 mb-4">
    <div class="stats-small stats-small--1 card card-small">
      <div class="card-body p-0 d-flex">
        <div class="d-flex flex-column m-auto">
          <div class="stats-small__data text-center">
            <span class="stats-small__label text-uppercase">Diterima</span>
            <h6 class="stats-small__value count my-3"><?php echo $modelTotalDiterima;?></h6>
          </div>
          <div class="stats-small__data">
            <span class="stats-small__percentage stats-small__percentage--increase"><?php echo $persen;?>%</span>
          </div>
        </div>
        <canvas height="120" class="blog-overview-stats-small-2"></canvas>
      </div>
    </div>
  </div>
  <div class="col-lg col-md-4 col-sm-6 mb-4">
    <div class="stats-small stats-small--1 card card-small">
      <div class="card-body p-0 d-flex">
        <div class="d-flex flex-column m-auto">
          <div class="stats-small__data text-center">
            <span class="stats-small__label text-uppercase">Ditolak</span>
            <h6 class="stats-small__value count my-3">0</h6>
          </div>
          <div class="stats-small__data">
            <span class="stats-small__percentage stats-small__percentage--decrease">0%</span>
          </div>
        </div>
        <canvas height="120" class="blog-overview-stats-small-3"></canvas>
      </div>
    </div>
  </div>
</div>
<!-- End Small Stats Blocks -->
<?php
if(isset($modelPerangkingan)){
?>
<div class="row">
  <!-- Top Referrals Component -->
  <div class="col-lg-4 col-md-12 col-sm-12 mb-4">
    <div class="card card-small">
      <div class="card-header border-bottom">
        <h6 class="m-0">Hasil Perangkingan</h6>
      </div>
      <div class="card-body p-0">
        <ul class="list-group list-group-small list-group-flush">
          <?php
          foreach ($modelPerangkingan as $key => $dtRanking) {
          ?>
          <li class="list-group-item d-flex px-3">
            <span class="text-semibold text-fiord-blue"><?php echo $dtRanking['nama_siswa'];?></span>
            <span class="ml-auto text-right text-semibold text-reagent-gray"><?php echo round($dtRanking['nilai'],2);?></span>
          </li>
          <?php
          }
          ?>
          
        </ul>
      </div>
    </div>
  </div>
  <!-- End Top Referrals Component -->
</div>
<?php
}
?>

<?php
}else{
?>
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Beranda</span>
  </div>
</div>
<!-- End Page Header -->
<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Beranda</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <p>Data pengaturan belum diatur, silahkan mengatur Tahun Ajaran saat ini <a href="<?= Yii::$app->request->baseUrl;?>/pengaturan">disini</a></p>
      </div>
    </div>
  </div>
</div>
<?php  
}
?>
<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model app\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Login';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="card card-small mb-4">
    <div class="card-header border-bottom">
    <h6 class="m-0">Login</h6>
    </div>
    <?php $form = ActiveForm::begin([
        'id' => 'login-form',
        'layout' => 'horizontal',
        'fieldConfig' => [
            'template' => "{label}\n<div class=\"col-lg-3\">{input}</div>\n<div class=\"col-lg-8\">{error}</div>",
            'labelOptions' => ['class' => 'col-lg-1 control-label'],
        ],
    ]); ?>
    <ul class="list-group list-group-flush">
    <li class="list-group-item p-3">
      <div class="row">
        <div class="col-sm-12 col-md-12">
            <?= $form->field($model, 'username')->textInput(['autofocus' => true]) ?>

            <?= $form->field($model, 'password')->passwordInput() ?>

            <?= $form->field($model, 'rememberMe')->checkbox([
                'template' => "<div class=\"col-lg-offset-1 col-lg-3\">{input} {label}</div>\n<div class=\"col-lg-8\">{error}</div>",
            ]) ?>
        </div>
        <div class="col-sm-12 col-md-6">
          
        </div>
        <div class="col-sm-12 col-md-12">
          <hr />
          <strong class="text-muted d-block my-2"></strong>
          <div class="row mb-3">
            <div class="col text-center">
              
              <?= Html::submitButton('Login', ['class' => 'mb-2 btn btn-sm btn-info mr-1', 'name' => 'login-button']) ?>
            </div>
          </div>
        </div>
      </div>
    </li>
    </ul>
    <?php ActiveForm::end(); ?>
</div>
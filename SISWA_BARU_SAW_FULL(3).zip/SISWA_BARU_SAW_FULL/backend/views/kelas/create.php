<?php

use yii\helpers\Html;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model backend\models\Kelas */

$this->title = 'Kelas Tambah';
$this->params['breadcrumbs'][] = ['label' => 'Kelas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

$listData = ArrayHelper::map($dtJurusan,'id_jurusan','nama_jurusan');

?>
<div class="card">
    <div class="card-body">
    	<h4 class="card-title"><?= Html::encode($this->title) ?></h4>

	    <?= $this->render('_form', [
	        'model' => $model,
	        'dtJurusan' => $listData,
	    ]) ?>
	</div>
</div>

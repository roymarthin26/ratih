<?php

use yii\helpers\Html;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model backend\models\Kelas */

$this->title = 'Update Kelas: ' . $model->nama_kelas. ' Jurusan: '.$model->jurusan->nama_jurusan;
$this->params['breadcrumbs'][] = ['label' => 'Kelas', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_kelas, 'url' => ['view', 'id' => $model->id_kelas]];
$this->params['breadcrumbs'][] = 'Update';

$listData = ArrayHelper::map($dtJurusan,'id_jurusan','nama_jurusan');
?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Ubah Data Kelas</span>
  </div>
</div>
<!-- End Page Header -->

<?= $this->render('_form', [
    'model' => $model,
    'dtJurusan' => $listData,
]) ?>
<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
?>



<div class="row">
  <div class="col-lg-12">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0"><?= Html::encode($this->title) ?></h6>
      </div>
      	
        <?php if (Yii::$app->session->hasFlash('error')): ?>
            <div class="alert alert-danger alert-dismissable">
             <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
             <h4><i class="icon fa fa-check"></i>Gagal!</h4>
             <?= Yii::$app->session->getFlash('error') ?>
            </div>
        <?php endif; ?>

        <?php $form = ActiveForm::begin([
		    'fieldConfig' => [
              'options' => [
                  'tag' => false,
              ],
          ],
		]); ?>
		<?php // echo $model->id_pengaturan;?>
		<?php // echo $model->id_pengaturan;?>

      <ul class="list-group list-group-flush">
        <li class="list-group-item p-3">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <strong class="text-muted d-block mb-2">Data Pengaturan</strong>
              
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="tgl_mulai">Tanggal Mulai</span>
                  </div>
                  <?= $form->field($model, 'tgl_mulai')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'tgl_mulai', 'type' => 'date'])->label(false) ?>
                </div>
              </div>

              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="tgl_selesai">Tanggal Selesai</span>
                  </div>
                  <?= $form->field($model, 'tgl_selesai')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'tgl_selesai', 'type' => 'date'])->label(false) ?>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              <strong class="text-muted d-block mb-2">Nilai Bobot Kriteria (%)</strong>
              <?php
              if(!empty($modelKriteria)){
                foreach ($modelKriteria as $dtKriteria) {
                  if(!empty($dataPK[$dtKriteria->id_kriteria])){
                    $val = $dataPK[$dtKriteria->id_kriteria];
                  }else{
                    $val = "";
                  }
              ?>
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="k<?php echo $dtKriteria->id_kriteria;?>"><?php echo $dtKriteria->nama_kriteria;?></span>
                  </div>
                  <?= $form->field($modelPK, 'id_kriteria['.$dtKriteria->id_kriteria.']')->textInput(['maxlength' => true, 'type'=>'number', 'min'=>0, 'max'=>100, 'class' => 'form-control', 'id' => 'k'.$dtKriteria->id_kriteria, 'value'=>$val])->label(false) ?>
                </div>
              </div>
              <?php
                }
              }
              ?>
            </div>
            <div class="col-sm-12 col-md-12">
              <hr />
              <strong class="text-muted d-block my-2"></strong>
              <div class="row mb-3">
                <div class="col text-center">
                  <a href="<?= Yii::$app->request->baseUrl;?>/pengaturan"><button type="button" class="mb-2 btn btn-sm btn-warning mr-1"><i class="material-icons">&#xE5C4;</i> Kembali</button></a>
                  <?= Html::submitButton($model->isNewRecord ? '<i class="material-icons">save</i> Simpan' : '<i class="material-icons">save</i> Update', ['class' => $model->isNewRecord ? 'mb-2 btn btn-sm btn-info mr-1' : 'mb-2 btn btn-sm btn-primary mr-1']) ?>
                </div>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <?php ActiveForm::end(); ?>
    </div>
  </div>
</div>
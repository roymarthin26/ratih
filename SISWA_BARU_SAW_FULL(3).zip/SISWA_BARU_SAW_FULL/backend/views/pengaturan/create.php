<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Pengaturan */

$this->title = 'Pengaturan Tambah';
$this->params['breadcrumbs'][] = ['label' => 'Pengaturan', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;



?>
<div class="card">
    <div class="card-body">
    	<h4 class="card-title"><?= Html::encode($this->title) ?></h4>

	    <?= $this->render('_form', [
	        'model' => $model,
	        'modelKriteria' => $modelKriteria,
            'modelPK' => $modelPK,
	    ]) ?>
	</div>
</div>

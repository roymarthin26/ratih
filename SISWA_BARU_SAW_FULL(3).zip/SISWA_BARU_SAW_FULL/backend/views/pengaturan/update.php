<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\Pengaturan */

$this->title = 'Update Pengaturan: ' . $model->tahun_ajaran;
$this->params['breadcrumbs'][] = ['label' => 'Pengaturan', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_pengaturan, 'url' => ['view', 'id' => $model->id_pengaturan]];
$this->params['breadcrumbs'][] = 'Update';
?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Ubah Data Pengaturan</span>
  </div>
</div>
<!-- End Page Header -->

<?= $this->render('_form', [
    'model' => $model,
    'modelKriteria' => $modelKriteria,
    'modelPK' => $modelPK,
    'dataPK' => $dataPK,
]) ?>
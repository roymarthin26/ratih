<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
$this->title = 'Data Pengaturan';
$this->params['breadcrumbs'][] = $this->title;
?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Data Pengaturan</span>
  </div>
</div>
<!-- End Page Header -->

<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Data Pengaturan</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <?php if (Yii::$app->session->hasFlash('success')): ?>
            <div class="alert alert-success alert-dismissable">
             <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
             <h4><i class="icon fa fa-check"></i>Berhasil!</h4>
             <?= Yii::$app->session->getFlash('success') ?>
            </div>
        <?php endif; ?>
        <strong class="text-muted d-block my-2"></strong>
        <form method="post" action="<?= Yii::$app->request->baseUrl;?>/pengaturan/delete" onsubmit="return hapus()">
        <input type="hidden" name="_csrf" value="<?=Yii::$app->request->getCsrfToken()?>" />
        <fieldset>
        <div class="col">
        <table class="table mb-0" id="example">
          <thead class="bg-light">
            <tr>
              <th scope="col" class="border-0" width="90px">
                <div class="custom-control custom-checkbox mb-1">
                  <input type="checkbox" class="custom-control-input" id="checkAll"/>
                  <label class="custom-control-label" for="checkAll">No</label>
                </div>
              </th>
              <th scope="col" class="border-0">Tahun Ajaran</th>
              <th scope="col" class="border-0">Tgl Mulai</th>
              <th scope="col" class="border-0">Tgl Selesai</th>
              <?php
              foreach ($dataKriteria as $dtKritria) {
              ?>
              <th scope="col" class="border-0"><?php echo $dtKritria->nama_kriteria;?></th>
              <?php
              }
              ?>
            </tr>
          </thead>
          <tbody>
            <?php
            $no=1;
            foreach ($dataPengaturan as $dtPengaturan) {
            ?>
            <tr>
              <td>
                <div class="custom-control custom-checkbox mb-1">
                  <input type="checkbox" class="custom-control-input" id="formsCheckboxDefault<?php echo $no;?>" name="pilih[<?php echo $dtPengaturan['id_pengaturan'];?>]" value="<?php echo $dtPengaturan['id_pengaturan'];?>">
                  <label class="custom-control-label" for="formsCheckboxDefault<?php echo $no;?>"> <?php echo $no++;?></label>
                </div>
              </td>
              <td><?php echo $dtPengaturan['tahun_ajaran'];?></td>
              <td><?php echo $dtPengaturan['tgl_mulai'];?></td>
              <td><?php echo $dtPengaturan['tgl_selesai'];?></td>
              <?php
              foreach ($dataKriteria as $dtKritria) {
                $dtPK = json_decode($dtPengaturan['pk']);
                $id_kriteria = $dtKritria->id_kriteria;
                if(!empty($dtPK->{$id_kriteria})){
                  $pk = $dtPK->{$id_kriteria};
                }else{
                  $pk = "";
                }
              ?>
              <td><?php echo $pk;?></td>
              <?php
              }
              ?>
              <td><a href="<?= Yii::$app->request->baseUrl;?>/pengaturan/update/<?php echo $dtPengaturan['id_pengaturan'];?>"><button type="button" class="mb-2 btn btn-sm btn-primary mr-1"><i class="material-icons">edit</i></button></a></td>
            </tr>
            <?php
            }
            ?>
          </tbody>
        </table>
        </div>
        <!-- Small Buttons -->
          <hr />
          <strong class="text-muted d-block my-2"></strong>
          <div class="row mb-3">
            <div class="col">
              <button type="submit" name="hapus" class="mb-2 btn btn-sm btn-danger mr-1"><i class="material-icons">delete_forever</i> Hapus Terpilih</button>
              <a href="<?= Yii::$app->request->baseUrl;?>/pengaturan/create">
              <button type="button" class="mb-2 btn btn-sm btn-info mr-1"><i class="material-icons">control_point</i> Tambah Pengaturan</button>
              </a>
            </div>
          </div>
          <!-- / Small Buttons -->
        </fieldset>
        </form>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});
</script>
<script type="text/javascript">
$(document).ready(function() {
  $('#example').DataTable();
} );
</script>
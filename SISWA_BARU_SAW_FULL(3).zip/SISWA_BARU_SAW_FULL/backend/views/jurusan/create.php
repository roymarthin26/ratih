<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Jurusan */

$this->title = 'Jurusan Tambah';
$this->params['breadcrumbs'][] = ['label' => 'Jurusan', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

?>
<div class="card">
    <div class="card-body">
    	<h4 class="card-title"><?= Html::encode($this->title) ?></h4>
        <h6 class="card-subtitle">Jurusan Tambah <code></code></h6>

	    <?= $this->render('_form', [
	        'model' => $model,
	    ]) ?>
	</div>
</div>

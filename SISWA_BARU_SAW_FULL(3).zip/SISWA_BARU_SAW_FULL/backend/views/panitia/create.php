<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Panitia */

$this->title = 'Panitia Tambah';
$this->params['breadcrumbs'][] = ['label' => 'Panitia', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

?>
<div class="card">
    <div class="card-body">
    	<h4 class="card-title"><?= Html::encode($this->title) ?></h4>
        <h6 class="card-subtitle">Panitia Tambah <code></code></h6>

	    <?= $this->render('_form', [
	        'model' => $model,
	    ]) ?>
	</div>
</div>

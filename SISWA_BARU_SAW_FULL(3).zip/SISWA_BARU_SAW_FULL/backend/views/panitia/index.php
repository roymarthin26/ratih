<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
$this->title = 'Data Panitia';
$this->params['breadcrumbs'][] = $this->title;
?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Data Panitia</span>
  </div>
</div>
<!-- End Page Header -->

<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Data Panitia</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <form method="post" action="<?= Yii::$app->request->baseUrl;?>/panitia/delete" onsubmit="return hapus()">
        <input type="hidden" name="_csrf" value="<?=Yii::$app->request->getCsrfToken()?>" />
        <fieldset>
        <div class="col">
        <table class="table mb-0" id="example">
          <thead class="bg-light">
            <tr>
              <th scope="col" class="border-0" width="90px">
                <div class="custom-control custom-checkbox mb-1">
                  <input type="checkbox" class="custom-control-input" id="checkAll"/>
                  <label class="custom-control-label" for="checkAll">No</label>
                </div>
              </th>
              <th scope="col" class="border-0">Username</th>
              <th scope="col" class="border-0">Password</th>
              <th scope="col" class="border-0">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no=1;
            foreach ($dataProvider as $hasil) {
            ?>
            <tr>
              <td>
                <div class="custom-control custom-checkbox mb-1">
                  <input type="checkbox" class="custom-control-input" id="formsCheckboxDefault<?php echo $no;?>" name="pilih[<?php echo $hasil->id_panitia;?>]" value="<?php echo $hasil->id_panitia;?>">
                  <label class="custom-control-label" for="formsCheckboxDefault<?php echo $no;?>"> <?php echo $no++;?></label>
                </div>
              </td>
              <td><?php echo $hasil->username;?></td>
              <td>*****</td>
              <td><a href="<?= Yii::$app->request->baseUrl;?>/panitia/update/<?php echo $hasil->id_panitia;?>"><button type="button" class="mb-2 btn btn-sm btn-primary mr-1"><i class="material-icons">edit</i></button></a></td>
            </tr>
            <?php
            }
            ?>
          </tbody>
        </table>
        </div>

        <!-- Small Buttons -->
          <hr />
          <strong class="text-muted d-block my-2"></strong>
          <div class="row mb-3">
            <div class="col">
              <button type="submit" name="hapus" class="mb-2 btn btn-sm btn-danger mr-1"><i class="material-icons">delete_forever</i> Hapus Terpilih</button>
              <a href="<?= Yii::$app->request->baseUrl;?>/panitia/create">
              <button type="button" class="mb-2 btn btn-sm btn-info mr-1"><i class="material-icons">control_point</i> Tambah Panitia</button>
              </a>
            </div>
          </div>
          <!-- / Small Buttons -->
        </fieldset>
        </form>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});
</script>
<script type="text/javascript">
$(document).ready(function() {
  $('#example').DataTable();
} );
</script>
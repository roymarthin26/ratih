<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
?>



<div class="row">
  <div class="col-lg-12">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0"><?= Html::encode($this->title) ?></h6>
      </div>
      	<?php $form = ActiveForm::begin([
         'fieldConfig' => [
              'options' => [
                  'tag' => false,
              ],
          ],
		    ]); ?>

      <ul class="list-group list-group-flush">
        <li class="list-group-item p-3">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="kode_kriteria">Kode</span>
                  </div>
                  <?= $form->field($model, 'kode_kriteria')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'kode_kriteria'])->label(false) ?>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              
            </div>
            <div class="col-sm-12 col-md-6">
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="nama_kriteria">Nama Kriteria</span>
                  </div>
                  <?= $form->field($model, 'nama_kriteria')->textInput(['maxlength' => true, 'class' => 'form-control', 'id' => 'nama_kriteria'])->label(false) ?>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              
            </div>
            
            
            <div class="col-sm-12 col-md-12">
              <hr />
              <strong class="text-muted d-block my-2"></strong>
              <div class="row mb-3">
                <div class="col text-center">
                  <a href="<?= Yii::$app->request->baseUrl;?>/kriteria"><button type="button" class="mb-2 btn btn-sm btn-warning mr-1"><i class="material-icons">&#xE5C4;</i> Kembali</button></a>
                  <?= Html::submitButton($model->isNewRecord ? '<i class="material-icons">save</i> Simpan' : '<i class="material-icons">save</i> Update', ['class' => $model->isNewRecord ? 'mb-2 btn btn-sm btn-info mr-1' : 'mb-2 btn btn-sm btn-primary mr-1']) ?>
                </div>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <?php ActiveForm::end(); ?>
    </div>
  </div>
</div>
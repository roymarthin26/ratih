<?php

use yii\helpers\Html;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model backend\models\Kriteria */

$this->title = 'Update Kriteria: ' . $model->nama_kriteria;
$this->params['breadcrumbs'][] = ['label' => 'Kriteria', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_kriteria, 'url' => ['view', 'id' => $model->id_kriteria]];
$this->params['breadcrumbs'][] = 'Update';

?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Ubah Data Kriteria</span>
  </div>
</div>
<!-- End Page Header -->

<?= $this->render('_form', [
    'model' => $model,
]) ?>
<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;

if(!empty($modelPengaturan)){

/* @var $this yii\web\View */
$ta = $modelSaatini->tahun_ajaran;
$this->title = 'Hasil Perankingan Calon Siswa Tahun Ajaran '.$ta;
$this->params['breadcrumbs'][] = $this->title;

$dtPengaturan = ArrayHelper::map($modelPengaturan,'id_pengaturan','tahun_ajaran');
$dtJurusan = ArrayHelper::map($modelJurusan,'id_jurusan','nama_jurusan');
?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Data Perankingan Calon Siswa</span>
  </div>
</div>
<!-- End Page Header -->

<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Hasil Perankingan Calon Siswa</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <fieldset>
        <strong class="text-muted d-block my-2"></strong>
        <div class="row mb-3">
          <div class="col">
            <?php $form = ActiveForm::begin([
             'fieldConfig' => [
                  'options' => [
                      'tag' => false,
                  ],
              ],
            ]); ?>

            <div class="col-sm-12 col-md-6">
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="id_pengaturan">Tahun Ajaran</span>
                  </div>
                  <?php
                  echo $form->field($model, 'id_pengaturan')
                  ->dropDownList($dtPengaturan,
                      ['prompt'=>'-- Pilih Tahun Ajaran --']    // options
                  )->label(false);
                  ?>
                </div>
              </div>
            </div>

            <div class="col-sm-12 col-md-6">
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="id_jurusan">Jurusan</span>
                  </div>
                  <?php
                  echo $form->field($model, 'id_jurusan')
                  ->dropDownList($dtJurusan,
                      ['prompt'=>'-- Pilih Jurusan --']    // options
                  )->label(false);
                  ?>
                </div>
              </div>
            </div>

            <div class="col-sm-12 col-md-12">
              <hr />
              <strong class="text-muted d-block my-2"></strong>
              <div class="row mb-3">
                <div class="col text-center">
                  
                  <?= Html::submitButton('<i class="material-icons">control_point</i> Lihat', ['class' => 'mb-2 btn btn-sm btn-warning mr-1']) ?>
                </div>
              </div>
            </div>

            <?php ActiveForm::end(); ?>
          </div>
        </div>
        <hr />
        <?php
        if(!empty($modelPerangkingan)){
        ?>
        <div class="col">
        <table class="table mb-0" id="example">
          <thead class="bg-light">
            <tr>
              <th scope="col" class="border-0">Identitas Siswa</th>
              <th scope="col" class="border-0">Nama Siswa</th>
              <th scope="col" class="border-0">Jurusan</th>
              <th scope="col" class="border-0">Kelas</th>
              <th scope="col" class="border-0">Nilai</th>
              <th scope="col" class="border-0">Urutan</th>
            </tr>
          </thead>
        </table>
        </div>
        <?php
        }
        ?>
        </fieldset>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
  $('#example').DataTable({
    "dom": 'Bfrltip',
    "buttons": [
        'excel', 'pdf', 'print'
    ],
    "processing": true,
    "ordering": true,
    "order": [[ 5, "asc" ]],
    "serverSide": true,
    "ajax": '<?php echo Yii::$app->request->baseUrl.'/hasil/ajax?ta='.$model->id_pengaturan.'&jur='.$model->id_jurusan;?>',
  });
} );
</script>

<?php
}else{
?>
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Data Perankingan Calon Siswa</span>
  </div>
</div>
<!-- End Page Header -->
<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Data Perankingan Calon Siswa</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <p>Data pengaturan belum diatur, silahkan mengatur Tahun Ajaran saat ini <a href="<?= Yii::$app->request->baseUrl;?>/pengaturan">disini</a></p>
      </div>
    </div>
  </div>
</div>
<?php  
}
?>
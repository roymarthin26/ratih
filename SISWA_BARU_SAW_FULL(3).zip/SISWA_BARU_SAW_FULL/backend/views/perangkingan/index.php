<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;

if(!empty($modelPengaturan)){

/* @var $this yii\web\View */
$ta = $modelSaatini->tahun_ajaran;
$this->title = 'Data Calon Siswa Tahun Ajaran '.$ta;
$this->params['breadcrumbs'][] = $this->title;

$dtPengaturan = ArrayHelper::map($modelPengaturan,'id_pengaturan','tahun_ajaran');
$dtJurusan = ArrayHelper::map($modelJurusan,'id_jurusan','nama_jurusan');
?>

<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Data Perankingan Calon Siswa</span>
  </div>
</div>
<!-- End Page Header -->

<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Proses Perankingan Calon Siswa</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <fieldset>

        <?php if (Yii::$app->session->hasFlash('success')): ?>
            <div class="alert alert-success alert-dismissable">
             <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
             <h4><i class="icon fa fa-check"></i>Berhasil!</h4>
             <?= Yii::$app->session->getFlash('success') ?>
            </div>
        <?php endif; ?>
        <?php if (Yii::$app->session->hasFlash('error')): ?>
            <div class="alert alert-danger alert-dismissable">
             <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
             <h4><i class="icon fa fa-check"></i>Gagal!</h4>
             <?= Yii::$app->session->getFlash('error') ?>
            </div>
        <?php endif; ?>
        
        <strong class="text-muted d-block my-2"></strong>
        <div class="row mb-3">
          <div class="col">
            <?php $form = ActiveForm::begin([
             'action' => Yii::$app->request->baseUrl.'/perangkingan',
             'fieldConfig' => [
                  'options' => [
                      'tag' => false,
                  ],
              ],
            ]); ?>

            <div class="col-sm-12 col-md-6">
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="id_pengaturan">Tahun Ajaran</span>
                  </div>
                  <?php
                  echo $form->field($model, 'id_pengaturan')
                  ->dropDownList($dtPengaturan,
                      ['prompt'=>'-- Pilih Tahun Ajaran --']    // options
                  )->label(false);
                  ?>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" for="id_jurusan">Jurusan</span>
                  </div>
                  <?php
                  echo $form->field($model, 'id_jurusan')
                  ->dropDownList($dtJurusan,
                      ['prompt'=>'-- Pilih Jurusan --']    // options
                  )->label(false);
                  ?>
                </div>
              </div>
            </div>

            <div class="col-sm-12 col-md-12">
              <hr />
              <strong class="text-muted d-block my-2"></strong>
              <div class="row mb-3">
                <div class="col text-center">
                  
                  <?= Html::submitButton('<i class="material-icons">control_point</i> Proses Perhitungan', ['class' => 'mb-2 btn btn-sm btn-info mr-1']) ?>
                </div>
              </div>
            </div>

            <?php ActiveForm::end(); ?>

          </div>
        </div>
        </fieldset>
      </div>
    </div>
  </div>
</div>

<?php
if(!empty($perhitungan_manual)){
?>
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Perhitungan Manual</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <?php
        $jmlKriteria = count($perhitungan_manual['kriteria']);

        $siswa_un = array();
        ?>
        <fieldset>
          <div class="col">
            <legend>ALTERNATIF</legend>
            <table class="table mb-0" id="example">
              <thead class="bg-light">
                <tr>
                  <th scope="col" class="border-0" rowspan="2">#</th>
                  <th scope="col" class="border-0" rowspan="2">Nama Siswa</th>
                  <th scope="col" class="border-0" colspan="<?php echo $jmlKriteria;?>">KRITERIA</th>
                </tr>
                <tr>
                  <?php
                  foreach ($perhitungan_manual['kriteria'] as $kode => $nama_kriteria) {
                  ?>
                  <th scope="col" class="border-0"><?php echo $nama_kriteria;?></th>
                  <?php
                  }
                  ?>
                </tr>
              </thead>
              <tbody>
                <?php
                foreach ($perhitungan_manual['siswa'][$model->id_jurusan]['nama'] as $id_siswa => $nama) {
                ?>
                <tr>
                  <td scope="col" class="border-0"></td>
                  <td scope="col" class="border-0"><?php echo $nama;?></td>
                <?php
                  foreach ($perhitungan_manual['kriteria'] as $kode => $nama_kriteria) {
                    $siswa_un[$kode][$id_siswa] = $perhitungan_manual['siswa'][$model->id_jurusan]['nilai'][$id_siswa][$kode];
                ?>
                  <td scope="col" class="border-0"><?php echo $perhitungan_manual['siswa'][$model->id_jurusan]['nilai'][$id_siswa][$kode];?></td>
                <?php
                  }
                ?>
                </tr>
                <?php
                }
                ?>
              </tbody>
            </table>
            <hr />
            <legend>HITUNG NORMALISASI MATRIK</legend>
            <style type="text/css">
              div.scroll {
                background-color: lightgreen;
                height: 450px;
                overflow: scroll;
              }
              hr.new {
                border-top: 1px dotted red;
              }
            </style>
            <div class="scroll">
            <?php
            foreach ($perhitungan_manual['kriteria'] as $kode => $nama_kriteria) {
              $max_r = max($siswa_un[$kode]);
            ?>
            MAX_R = MAX(<?php echo implode(",", $siswa_un[$kode]);?>) = <b><?php echo $max_r;?></b>
            <br />
            <?php
              foreach ($perhitungan_manual['siswa'][$model->id_jurusan]['nama'] as $id_siswa => $nama) {
                $nilai = $perhitungan_manual['siswa'][$model->id_jurusan]['nilai'][$id_siswa][$kode];
                $hasil = $nilai/$max_r;
            ?>
            <?php 
            echo $nama.', '.$kode.' = '.$nilai.'/'.$max_r.' = '.round($hasil,3);
            ?>
            <br />
            <?php
              }
            ?>
            <hr class="new">
            <?php
            }
            ?>
            </div>
            <hr />
            <legend>HASIL NORMALISASI MATRIK</legend>
            <table class="table mb-0" id="example2">
              <thead class="bg-light">
                <tr>
                  <th scope="col" class="border-0" rowspan="2">#</th>
                  <th scope="col" class="border-0" rowspan="2">Nama Siswa</th>
                  <th scope="col" class="border-0" colspan="<?php echo $jmlKriteria;?>">KRITERIA</th>
                </tr>
                <tr>
                  <?php
                  foreach ($perhitungan_manual['kriteria'] as $kode => $nama_kriteria) {
                  ?>
                  <th scope="col" class="border-0"><?php echo $nama_kriteria;?></th>
                  <?php
                  }
                  ?>
                </tr>
              </thead>
              <tbody>
                <?php
                foreach ($perhitungan_manual['siswa'][$model->id_jurusan]['nama'] as $id_siswa => $nama) {
                ?>
                <tr>
                  <td scope="col" class="border-0"></td>
                  <td scope="col" class="border-0"><?php echo $nama;?></td>
                <?php
                  foreach ($perhitungan_manual['kriteria'] as $kode => $nama_kriteria) {
                    $nilai = $perhitungan_manual['matrikR'][$model->id_jurusan][$id_siswa][$kode];
                ?>
                  <td scope="col" class="border-0"><?php echo round($nilai, 3);?></td>
                <?php
                  }
                ?>
                </tr>
                <?php
                }
                ?>
              </tbody>
            </table>
            <hr />
            <legend>BOBOT (W)</legend>
            <table class="table mb-0" id="example3">
              <thead class="bg-light">
                <tr>
                  <?php
                  foreach ($perhitungan_manual['kriteria'] as $kode => $nama_kriteria) {
                  ?>
                  <th scope="col" class="border-0"><?php echo $nama_kriteria;?></th>
                  <?php
                  }
                  ?>
                </tr>
              </thead>
              <tbody>
                <?php
                foreach ($perhitungan_manual['kriteria'] as $kode => $nama_kriteria) {
                ?>
                <td scope="col" class="border-0"><?php echo $perhitungan_manual['bobot'][$kode];?></td>
                <?php
                }
                ?>
              </tbody>
            </table>
            <hr />
            <legend>MENGHITUNG NILAI V</legend>
            <table class="table mb-0" id="example4">
              <thead>
                <tr>
                  <th scope="col" class="border-0">#</th>
                  <th scope="col" class="border-0">Nama Siswa</th>
                  <th scope="col" class="border-0">Perhitungan V</th>
                  <th scope="col" class="border-0">=</th>
                </tr>
              </thead>
              <tbody>
            <?php
            //Preverensi tiap Alternatif 
            $pa = array();
            foreach ($perhitungan_manual['matrikR'][$model->id_jurusan] as $id_siswa => $arrNilai) {
                $kali = array();
                $out_kali = array();
                foreach ($arrNilai as $key_nilai => $val) {
                  $kali[$key_nilai] = $perhitungan_manual['bobot'][$key_nilai] * $val;
                  $val = round($val,3);
                  $out_kali[$key_nilai] = '('.$perhitungan_manual['bobot'][$key_nilai].'*'.$val.')';
                }
                $pa[$id_siswa] = array_sum($kali);
            ?>
              <tr>
                <td></td>
                <td><?php echo $perhitungan_manual['siswa'][$model->id_jurusan]['nama'][$id_siswa];?></td>
                <td><?php echo implode(" + ", $out_kali);?></td>
                <td><?php echo round($pa[$id_siswa], 3);?></td>
              </tr>
            <?php
            }
            ?>
              </tbody>
            </table>
            <hr />
            <legend>HASIL PERANKINGAN</legend>
            <table class="table mb-0" id="hasil">
            <thead class="bg-light">
              <tr>
                <th scope="col" class="border-0">Identitas Siswa</th>
                <th scope="col" class="border-0">Nama Siswa</th>
                <th scope="col" class="border-0">Jurusan</th>
                <th scope="col" class="border-0">Kelas</th>
                <th scope="col" class="border-0">Nilai</th>
                <th scope="col" class="border-0">Urutan</th>
              </tr>
            </thead>
          </table>
          </div>

        </fieldset>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$(document).ready(function() {
  var t = $('#example').DataTable({
    "columnDefs": [ {
        "searchable": false,
        "orderable": false,
        "targets": 0
    } ],
    "ordering": true,
    "order": [[ 1, "asc" ]],
  });
  t.on( 'order.dt search.dt', function () {
      t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
          cell.innerHTML = i+1;
      } );
  } ).draw();
  //TABLE MATRIK R
  var tMatrik = $('#example2').DataTable({
    "columnDefs": [ {
        "searchable": false,
        "orderable": false,
        "targets": 0
    } ],
    "ordering": true,
    "order": [[ 1, "asc" ]],
  });
  tMatrik.on( 'order.dt search.dt', function () {
      tMatrik.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
          cell.innerHTML = i+1;
      } );
  } ).draw();
  //TABLE V
  var tV = $('#example4').DataTable({
    "columnDefs": [ {
        "searchable": false,
        "orderable": false,
        "targets": 0
    } ],
    "ordering": true,
    "order": [[ 1, "asc" ]],
  });
  tV.on( 'order.dt search.dt', function () {
      tV.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
          cell.innerHTML = i+1;
      } );
  } ).draw();
  //HASIL PERANKINGAN
  $('#hasil').DataTable({
    "dom": 'Bfrltip',
    "buttons": [
        'excel', 'pdf', 'print'
    ],
    "processing": true,
    "ordering": true,
    "order": [[ 5, "asc" ]],
    "serverSide": true,
    "ajax": '<?php echo Yii::$app->request->baseUrl.'/hasil/ajax?ta='.$model->id_pengaturan.'&jur='.$model->id_jurusan;?>',
  });
} );
</script>
<?php
}
?>

<?php
}else{
?>
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Data Perankingan Calon Siswa</span>
  </div>
</div>
<!-- End Page Header -->
<!-- Default Light Table -->
<div class="row">
  <div class="col">
    <div class="card card-small mb-4">
      <div class="card-header border-bottom">
        <h6 class="m-0">Data Perankingan Calon Siswa</h6>
      </div>
      <div class="card-body p-0 pb-3 text-center">
        <p>Data pengaturan belum diatur, silahkan mengatur Tahun Ajaran saat ini <a href="<?= Yii::$app->request->baseUrl;?>/pengaturan">disini</a></p>
      </div>
    </div>
  </div>
</div>
<?php  
}
?>
<?php

namespace backend\assets;

use yii\web\AssetBundle;

/**
 * Main backend application asset bundle.
 */
class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'https://use.fontawesome.com/releases/v5.0.6/css/all.css',
        'https://fonts.googleapis.com/icon?family=Material+Icons',
        //'https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css',
        'bootstrap-4.3.1/dist/css/bootstrap.min.css',
        'styles/shards-dashboards.1.1.0.min.css',
        'styles/extras.1.1.0.min.css',
        'styles/buttons.dataTables.min.css',
    ];
    public $js = [
        //'https://buttons.github.io/buttons.js',
        //'https://code.jquery.com/jquery-3.3.1.min.js',
        'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js',
        //'https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js',
        'bootstrap-4.3.1/dist/js/bootstrap.min.js',
        'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js',
        'https://unpkg.com/shards-ui@latest/dist/js/shards.min.js',
        'https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js',
        'scripts/extras.1.1.0.min.js',
        'scripts/dataTables.buttons.min.js',
        'scripts/jszip.min.js',
        'scripts/pdfmake.min.js',
        'scripts/vfs_fonts.js',
        'scripts/buttons.html5.min.js',
        'scripts/buttons.print.min.js',
        //'scripts/shards-dashboards.1.1.0.min.js',
        //'scripts/app/app-blog-overview.1.1.0.js',
    ];
    public $depends = [
    ];
}
